package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.EditorViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppLayout()
            }
        }
    }
}

@Composable
fun MainAppLayout() {
    val viewModel: EditorViewModel = viewModel()
    var activeTab by remember { mutableStateOf(0) }
    
    // Auto-select editor tab when a project is selected
    val selectedProject by viewModel.selectedProject.collectAsState()

    val tabs = listOf(
        NavigationTabItem("Projects", Icons.Default.FolderOpen, "projects_tab"),
        NavigationTabItem("Editor", Icons.Default.ContentCut, "editor_tab"),
        NavigationTabItem("Local AI", Icons.Default.Memory, "ai_tab"),
        NavigationTabItem("Render", Icons.Default.Publish, "render_tab"),
        NavigationTabItem("DSP Settings", Icons.Default.Settings, "settings_tab")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = GraphiteSurface,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SlateDark,
                            selectedTextColor = GlowCyan,
                            indicatorColor = GlowCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = SlateDark
        ) {
            when (activeTab) {
                0 -> ProjectsScreen(
                    viewModel = viewModel,
                    onProjectSelected = { activeTab = 1 } // Jump directly to Editor Workspace!
                )
                1 -> EditorScreen(
                    viewModel = viewModel
                )
                2 -> AIModelCenterScreen()
                3 -> ExportScreen(
                    viewModel = viewModel
                )
                4 -> SettingsScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}

data class NavigationTabItem(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)
