package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProjectEntity
import com.example.ui.EditorViewModel
import com.example.ui.theme.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProjectsScreen(
    viewModel: EditorViewModel,
    onProjectSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val projects by viewModel.projects.collectAsState()
    val selectedProject by viewModel.selectedProject.collectAsState()
    val context = LocalContext.current

    var showCreatorDialog by remember { mutableStateOf(false) }

    // Dialog state variables
    var newProjectName by remember { mutableStateOf("") }
    var selectedTemplate by remember { mutableStateOf("Manga Explanation") }
    var selectedAspectRatio by remember { mutableStateOf("16:9") }
    var selectedResolution by remember { mutableStateOf("1080p") }
    var selectedFps by remember { mutableStateOf(30) }
    var selectedCodec by remember { mutableStateOf("H.264") }
    var selectedSubtitleStyle by remember { mutableStateOf(1) }

    val templates = listOf(
        TemplateConfig("Manga Explanation", "16:9", Icons.Default.MovieFilter, "Cinema ratio, Bangers bold subtitles, slow Ken Burns zooms, smooth crossfades."),
        TemplateConfig("Manhwa Recap", "16:9", Icons.Default.AutoAwesome, "Cinema ratio, neon outline captions, fast zoom movements, white flash cuts."),
        TemplateConfig("YouTube Shorts", "9:16", Icons.Default.StayCurrentPortrait, "TikTok green bold style subtitles, high-impact zooms, shake effects."),
        TemplateConfig("TikTok", "9:16", Icons.Default.PhoneAndroid, "Aggressive dynamic subtitles, zoom-in action camera, push transitions."),
        TemplateConfig("Comic Recap", "16:9", Icons.Default.MenuBook, "Classic graphic novel layout, minimum zoom, minimalist Helvetica subtitles."),
        TemplateConfig("Instagram Reels", "9:16", Icons.Default.VideoLibrary, "Minimal slide transitions, clean typography, lo-fi aesthetic pan movements.")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. TOP HEADER & APP PROFILE
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "EdgeEdit Pro",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Offline local AI Manga Recap & Explanation Creator",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Premium Mode",
                    tint = GlowCyan,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // 2. LARGE CREATE PROJECT BUTTON
        item {
            Card(
                onClick = {
                    val dateStr = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date())
                    newProjectName = "Manga Recap $dateStr"
                    showCreatorDialog = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_project_button"),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(ElectricViolet, GlowCyan)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(ElectricViolet, GlowCyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = "Create",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Create New Project",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Generate a storyboarding track. Instantly binds your recorded speech with local manga panel crops and subtitle styling presets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            lineHeight = 16.sp
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // 3. WORKSPACE ACTIVE BANNER
        if (selectedProject != null) {
            val active = selectedProject!!
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GlowCyan.copy(alpha = 0.12f))
                        .border(1.dp, GlowCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(GlowCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = null,
                                    tint = SlateDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "ACTIVE WORKSPACE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GlowCyan,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = active.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Button(
                            onClick = onProjectSelected,
                            colors = ButtonDefaults.buttonColors(containerColor = GlowCyan),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Open Editor", color = SlateDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 4. RECENT PROJECTS SECTION
        item {
            Text(
                text = "RECENT STORYBOARD PROJECTS (${projects.size})",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (projects.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Brush,
                            contentDescription = "Empty",
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Project Catalog is Empty",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Click the Large Create button above to assemble your first storyboard recap.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(projects) { project ->
                val isActive = selectedProject?.id == project.id
                ProjectMangaCard(
                    project = project,
                    isActive = isActive,
                    onSelect = {
                        viewModel.selectProject(project.id)
                        onProjectSelected()
                    },
                    onDelete = { viewModel.deleteProject(project) }
                )
            }
        }

        // 5. STORAGE ANALYZER SECTION
        item {
            Text(
                text = "ON-DEVICE STORAGE ANALYZER",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("System Directories", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Text("82.5 GB / 128 GB FREE", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated storage meter
                    LinearProgressIndicator(
                        progress = { 0.35f },
                        color = ElectricViolet,
                        trackColor = SlateDark,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50))
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SlateDark)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("Manga Cache", fontSize = 8.sp, color = TextMuted)
                                Text("12.4 MB", fontSize = 11.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                Text("120 images cached", fontSize = 7.sp, color = TextMuted)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SlateDark)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("Audio Snippets", fontSize = 8.sp, color = TextMuted)
                                Text("32.1 MB", fontSize = 11.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                Text("WAV PCM raw buffers", fontSize = 7.sp, color = TextMuted)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SlateDark)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("Local AI Models", fontSize = 8.sp, color = TextMuted)
                                Text("76.2 MB", fontSize = 11.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                Text("Tiny ONNX weights", fontSize = 7.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        // 6. QUICK SETTINGS SECTION
        item {
            Text(
                text = "ENGINE QUICK SETTINGS",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Local GPU Render Pipeline", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Utilizes hardware MediaCodec shaders for instant MP4 compositions", fontSize = 9.sp, color = TextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("HARDWARE ON", color = Color(0xFF10B981), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Performance Mode", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Calibrate mobile cores for heavy voice segmentation tasks", fontSize = 9.sp, color = TextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ElectricViolet.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("MAX SPEED", color = ElectricViolet, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Eye-Safe Dark Canvas Theme", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text("Always-on dark mode to prevent battery drain & late night strain", fontSize = 9.sp, color = TextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SlateDark)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("SLATE DARK", color = TextPrimary, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 7. ABOUT EDGEEDIT PRO SECTION
        item {
            Text(
                text = "ABOUT THE RECAP ENGINE",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "EdgeEdit Pro • Stable v1.2",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Designed for creators editing high-impact recap videos on-device. Integrates local Silero voice activity detection, deep RNNoise spectral gates, and custom multi-panel manga presets without sending any content to cloud networks.",
                        fontSize = 10.sp,
                        color = TextMuted,
                        lineHeight = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("100% OFFLINE DATA PRIVACY", fontSize = 8.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                        Text("MADE IN JETPACK COMPOSE", fontSize = 8.sp, color = TextMuted)
                    }
                }
            }
        }
    }

    // CREATE MANGA EXPLANATION PROJECT CONFIGURATION DIALOG
    if (showCreatorDialog) {
        AlertDialog(
            onDismissRequest = { showCreatorDialog = false },
            containerColor = GraphiteSurface,
            modifier = Modifier.fillMaxWidth(0.95f),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MovieFilter, contentDescription = null, tint = ElectricViolet)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Configure Manga Studio", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                val dialogScrollState = rememberScrollState()
                Column(
                    modifier = Modifier
                        .verticalScroll(dialogScrollState)
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Name Input
                    OutlinedTextField(
                        value = newProjectName,
                        onValueChange = { newProjectName = it },
                        label = { Text("Project Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricViolet,
                            unfocusedBorderColor = TextMuted,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Template Category Slider Selector
                    Text("CHOOSE CREATOR TEMPLATE PRESET", style = MaterialTheme.typography.labelSmall, color = GlowCyan, fontWeight = FontWeight.Bold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(templates) { template ->
                            val isChosen = selectedTemplate == template.name
                            Box(
                                modifier = Modifier
                                    .width(180.dp)
                                    .height(115.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isChosen) ElectricViolet.copy(alpha = 0.25f) else SlateDark)
                                    .border(1.5.dp, if (isChosen) ElectricViolet else SlateDark.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedTemplate = template.name
                                        selectedAspectRatio = template.defaultRatio
                                        // Auto-tune ratios
                                        if (template.name == "YouTube Shorts" || template.name == "TikTok" || template.name == "Instagram Reels") {
                                            selectedSubtitleStyle = 4 // TikTok Highlight
                                        } else {
                                            selectedSubtitleStyle = 1 // Yellow Bangers
                                        }
                                    }
                                    .padding(8.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(template.icon, contentDescription = null, tint = if (isChosen) GlowCyan else TextPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(template.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(template.description, fontSize = 9.sp, color = TextMuted, lineHeight = 12.sp)
                                    Spacer(modifier = Modifier.weight(1f))
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.End)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(GraphiteSurface)
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(template.defaultRatio, fontSize = 8.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Format parameter chips
                    Text("MANAGE VIDEO COMPOSITION FORMATS", style = MaterialTheme.typography.labelSmall, color = GlowCyan, fontWeight = FontWeight.Bold)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Resolution", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(SlateDark)) {
                                listOf("720p", "1080p", "4K").forEach { res ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { selectedResolution = res }
                                            .background(if (selectedResolution == res) ElectricViolet else Color.Transparent)
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(res, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Aspect Ratio", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(SlateDark)) {
                                listOf("16:9", "9:16", "1:1").forEach { ratio ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { selectedAspectRatio = ratio }
                                            .background(if (selectedAspectRatio == ratio) ElectricViolet else Color.Transparent)
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(ratio, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FPS (Frames Per Sec)", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(SlateDark)) {
                                listOf(24, 30, 60).forEach { f ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { selectedFps = f }
                                            .background(if (selectedFps == f) ElectricViolet else Color.Transparent)
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${f}fps", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Codec Output", fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(SlateDark)) {
                                listOf("H.264", "H.265").forEach { cod ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { selectedCodec = cod }
                                            .background(if (selectedCodec == cod) ElectricViolet else Color.Transparent)
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(cod, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Subtitle presets selection
                    Text("CHOOSE SUBTITLE STYLE PRESETS", style = MaterialTheme.typography.labelSmall, color = GlowCyan, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            SubtitlePreset(1, "Bangers", Color.Yellow, "Bangers Yellow"),
                            SubtitlePreset(2, "Orbitron", Color(0xFF00F2FE), "Neon Cyan"),
                            SubtitlePreset(3, "Helvetica", Color.White, "Minimal white"),
                            SubtitlePreset(4, "Impact", Color(0xFF10B981), "TikTok Bold")
                        ).forEach { preset ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selectedSubtitleStyle == preset.id) ElectricViolet.copy(alpha = 0.3f) else SlateDark)
                                    .border(1.dp, if (selectedSubtitleStyle == preset.id) ElectricViolet else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { selectedSubtitleStyle = preset.id }
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "CAPS",
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                                        fontWeight = FontWeight.Black,
                                        color = preset.color,
                                        fontSize = 11.sp
                                    )
                                    Text(preset.label, fontSize = 8.sp, color = TextMuted)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = newProjectName.trim().ifEmpty { "Manga Explanation" }
                        viewModel.createCustomProject(
                            name = name,
                            resolution = selectedResolution,
                            fps = selectedFps,
                            aspectRatio = selectedAspectRatio,
                            codec = selectedCodec,
                            subtitleStyleId = selectedSubtitleStyle,
                            templateId = selectedTemplate
                        )
                        showCreatorDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GlowCyan)
                ) {
                    Text("Auto-Generate Storyboard", color = SlateDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatorDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            }
        )
    }
}

@Composable
fun ProjectMangaCard(
    project: ProjectEntity,
    isActive: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit
) {
    val df = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val formattedDate = remember(project.createdAt) { df.format(Date(project.createdAt)) }
    val formattedDuration = remember(project.videoDurationMs) {
        val seconds = (project.videoDurationMs / 1000) % 60
        val minutes = (project.videoDurationMs / (1000 * 60)) % 60
        String.format("%02d:%02d", minutes, seconds)
    }
    val formattedSize = remember(project.videoSizeByte) {
        String.format("%.2f MB", project.videoSizeByte / (1024.0 * 1024.0))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, if (isActive) GlowCyan else Color.Transparent, RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .testTag("project_item_${project.id}"),
        colors = CardDefaults.cardColors(containerColor = if (isActive) DarkCardBg else GraphiteSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Visual Placeholder represent aspect ratio
            Box(
                modifier = Modifier
                    .size(width = 65.dp, height = 65.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SlateDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (project.aspectRatio == "9:16") Icons.Default.PhoneAndroid else Icons.Default.LiveTv,
                    contentDescription = null,
                    tint = if (isActive) GlowCyan else TextMuted,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Template Badging
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ElectricViolet.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = project.templateId,
                            color = ElectricViolet,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = project.aspectRatio,
                        style = MaterialTheme.typography.labelSmall,
                        color = GlowCyan,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = project.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "⏱️ $formattedDuration", fontSize = 10.sp, color = TextMuted)
                    Text(text = "📦 $formattedSize", fontSize = 10.sp, color = TextMuted)
                    Text(text = "🎬 ${project.resolution} (${project.fps}fps)", fontSize = 10.sp, color = TextMuted)
                    Text(text = formattedDate, fontSize = 10.sp, color = TextMuted)
                }

                Spacer(modifier = Modifier.height(6.dp))

                // AI Processing tags
                val (statusColor, statusText) = when (project.status) {
                    "Analyzing" -> Pair(ElectricViolet, "Whisper segmenting speech tracks...")
                    "Exporting" -> Pair(NeonCoral, "Encoding H.264 compositions...")
                    "Analyzed" -> Pair(Color(0xFF10B981), "AI Clean & Card storyboarding ready")
                    else -> Pair(TextMuted, "Imported")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(statusColor))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = statusText, fontSize = 9.sp, color = statusColor, fontWeight = FontWeight.Bold)
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_project_${project.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextMuted.copy(alpha = 0.4f)
                )
            }
        }
    }
}

// Data structures for visual catalog Dialog
data class TemplateConfig(
    val name: String,
    val defaultRatio: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val description: String
)

data class SubtitlePreset(
    val id: Int,
    val font: String,
    val color: Color,
    val label: String
)
