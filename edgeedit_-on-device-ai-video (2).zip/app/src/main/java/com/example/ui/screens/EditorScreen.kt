package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicTextField
import com.example.data.ProjectEntity
import com.example.data.TimelineSegment
import com.example.ui.EditorViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    modifier: Modifier = Modifier
) {
    val selectedProject by viewModel.selectedProject.collectAsState()
    val segments by viewModel.activeSegments.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playheadPositionMs by viewModel.playheadPositionMs.collectAsState()
    val waveformSamples by viewModel.waveformSamples.collectAsState()

    var activeSceneCard by remember { mutableStateOf<TimelineSegment?>(null) }
    var showPanelSelectorDialog by remember { mutableStateOf(false) }
    var dialogTargetSegment by remember { mutableStateOf<TimelineSegment?>(null) }
    
    val timelineScrollState = rememberScrollState()

    // Mock manga panels database
    val mockMangaPanels = listOf(
        MangaPanelCrop("Protagonist Intro", "Double-page epic introduction panel", Color(0xFF3B82F6)),
        MangaPanelCrop("Villain Grin", "Close-up of evil villain smiling maliciously", Color(0xFFEF4444)),
        MangaPanelCrop("Special Attack spread", "Action spread panel showing a dynamic elemental slash", Color(0xFFF59E0B)),
        MangaPanelCrop("Character Shocked", "Vocal text bubbles surrounding shocked protagonist", Color(0xFF10B981)),
        MangaPanelCrop("Shadowy Cliffhanger", "Shadow silhouette frame with text translations", Color(0xFF6366F1))
    )

    // Automatically locate active speaking subtitle card at playhead
    val currentActiveSegment = remember(playheadPositionMs, segments) {
        segments.find { playheadPositionMs >= it.startMs && playheadPositionMs < it.endMs && !it.isExcluded }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDark)
            .padding(10.dp)
    ) {
        if (selectedProject == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Book, contentDescription = "Empty", tint = TextMuted, modifier = Modifier.size(60.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Select a Manga Project", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Load or create a new recap project on the Projects tab first.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        } else {
            val project = selectedProject!!

            // Split pane: Upper Visuals & Controls | Storyboard cards list
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // LEFT: CANVAS MONITOR (Video player & Subtitles)
                Card(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxHeight(),
                    colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            "ON-DEVICE MONITOR",
                            style = MaterialTheme.typography.labelSmall,
                            color = GlowCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        // SCREEN CANVAS representing 16:9 or 9:16 vertical workspace
                        val canvasAspect = if (project.aspectRatio == "9:16") 0.56f else 1.77f
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            currentActiveSegment?.let { seg ->
                                // Draw Panel Layout inside
                                val hasPanel = seg.panelImagePath != null
                                if (hasPanel) {
                                    val panelDetails = mockMangaPanels.find { seg.panelImagePath?.contains(it.name) == true } 
                                        ?: mockMangaPanels[0]

                                    if (seg.panelWidescreenFill && project.aspectRatio == "16:9") {
                                        // Automated Widescreen Blur Fill: Double blurred sides framing the vertical panel
                                        Row(modifier = Modifier.fillMaxSize()) {
                                            Box(modifier = Modifier.weight(0.3f).fillMaxHeight().background(panelDetails.color.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                                Text("BLUR", color = Color.White.copy(alpha = 0.2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .weight(0.4f)
                                                    .fillMaxHeight()
                                                    .background(panelDetails.color),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Brush, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                                            }
                                            Box(modifier = Modifier.weight(0.3f).fillMaxHeight().background(panelDetails.color.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                                Text("BLUR", color = Color.White.copy(alpha = 0.2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else {
                                        // Centered normal panel
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(panelDetails.color),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Image, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                                        }
                                    }

                                    // Camera AI Action label overlays
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(10.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(ElectricViolet.copy(alpha = 0.85f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            "🎥 AI Motion: ${seg.cameraMotionType} (${seg.cameraMotionSpeed})",
                                            fontSize = 9.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    // Missing Manga panel illustration placeholder
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.BrokenImage, contentDescription = null, tint = TextMuted.copy(alpha = 0.25f), modifier = Modifier.size(48.dp))
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Waiting for Manga Panel", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                                        Text("Bind panel in right cards", fontSize = 8.sp, color = TextMuted)
                                    }
                                }

                                // Overlay styled captions based on selected subtitle style
                                seg.transcriptText?.let { text ->
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomCenter)
                                            .padding(bottom = 14.dp, start = 12.dp, end = 12.dp)
                                    ) {
                                        when (project.subtitleStyleId) {
                                            1 -> { // Bangers Yellow outlined
                                                Text(
                                                    text = text.uppercase(),
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontFamily = FontFamily.SansSerif,
                                                        fontWeight = FontWeight.Black,
                                                        color = Color.Yellow,
                                                        textAlign = TextAlign.Center,
                                                        letterSpacing = 1.sp
                                                    ),
                                                    modifier = Modifier
                                                        .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                                )
                                            }
                                            2 -> { // Neon glow blue
                                                Text(
                                                    text = text,
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontFamily = FontFamily.Monospace,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF00F2FE),
                                                        textAlign = TextAlign.Center
                                                    ),
                                                    modifier = Modifier
                                                        .border(1.dp, Color(0xFF00F2FE), RoundedCornerShape(8.dp))
                                                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                            3 -> { // Helvetica minimal
                                                Text(
                                                    text = text,
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontFamily = FontFamily.SansSerif,
                                                        color = Color.White,
                                                        textAlign = TextAlign.Center
                                                    ),
                                                    modifier = Modifier
                                                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                            else -> { // TikTok Dynamic Green bold
                                                Text(
                                                    text = text.uppercase(),
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontFamily = FontFamily.Serif,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = Color(0xFF10B981),
                                                        textAlign = TextAlign.Center
                                                    ),
                                                    modifier = Modifier
                                                        .background(Color.Black.copy(alpha = 0.9f), RoundedCornerShape(2.dp))
                                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                // Transition highlight overlay
                                if (seg.transitionType != "None" && playheadPositionMs < (seg.startMs + 500)) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                if (seg.transitionType == "Flash") Color.White.copy(alpha = 0.5f)
                                                else Color.Black.copy(alpha = 0.4f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("⚡ Transition: ${seg.transitionType}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } ?: run {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.VolumeOff, contentDescription = null, tint = TextMuted.copy(alpha = 0.3f), modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("[Muted Pause Segment]", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Player action controller
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(
                                onClick = { viewModel.togglePlay() },
                                modifier = Modifier.testTag("editor_play_pause_button")
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = if (isPlaying) GlowCyan else Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Slider(
                                value = playheadPositionMs.toFloat(),
                                onValueChange = { viewModel.seekTo(it.toLong()) },
                                valueRange = 0f..project.videoDurationMs.toFloat().coerceAtLeast(1f),
                                colors = SliderDefaults.colors(
                                    thumbColor = GlowCyan,
                                    activeTrackColor = GlowCyan,
                                    inactiveTrackColor = SlateDark
                                ),
                                modifier = Modifier.weight(1f).testTag("playhead_slider")
                            )

                            Text(
                                text = formatTime(playheadPositionMs) + " / " + formatTime(project.videoDurationMs),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                    }
                }

                // RIGHT: SCENIC STORYBOARD CARDS (Timeline block adjustments)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            "SCENIC STORYBOARD CARDS (${segments.size})",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(segments) { segment ->
                                StoryboardSceneCard(
                                    segment = segment,
                                    isActive = currentActiveSegment?.id == segment.id,
                                    onPanelClick = {
                                        dialogTargetSegment = segment
                                        showPanelSelectorDialog = true
                                    },
                                    onExcludeToggle = { viewModel.toggleSegmentExclusion(segment) },
                                    onSubtitleChange = { text -> viewModel.updateSegmentSubtitle(segment, text) },
                                    onMotionChange = { mot, spd, foc -> viewModel.updateCameraMotion(segment, mot, spd, foc) },
                                    onWidescreenFillToggle = { viewModel.duplicateMangaPanel3xCinematic(segment) },
                                    onTransitionChange = { tr -> viewModel.updateTransition(segment, tr, 500) }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // BOTTOM: NARRATIVE SOUNDWAVE TIMELINE TRACK
            Text(
                "NARRATION SOUNDWAVE TRACK (AUTOMATED AI JUMP CUTS)",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(85.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(GraphiteSurface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(timelineScrollState)
                ) {
                    val trackWidth = 1400.dp
                    Row(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(trackWidth)
                    ) {
                        segments.forEach { segment ->
                            val duration = segment.endMs - segment.startMs
                            val ratio = duration.toFloat() / project.videoDurationMs
                            val segmentWidth = trackWidth * ratio

                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(segmentWidth)
                                    .background(
                                        when {
                                            segment.isExcluded -> CutSegmentColor
                                            segment.isSilence -> Color(0x1CF43F5E)
                                            segment.isFiller -> FillerSegmentColor
                                            segment.soundCategory == "LAUGHTER" -> LaughterSegmentColor
                                            else -> KeepSegmentColor
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (currentActiveSegment?.id == segment.id) GlowCyan else SlateDark.copy(alpha = 0.4f)
                                    )
                                    .clickable {
                                        viewModel.seekTo(segment.startMs)
                                    }
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 4.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    // Visual spikes representing the simulated wav heights
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val barCount = (duration / 400).toInt().coerceIn(4, 18)
                                        for (b in 0 until barCount) {
                                            val barVal = waveformSamples.getOrNull((segment.playOrder * 10 + b) % waveformSamples.size.coerceAtLeast(1)) ?: 0.3f
                                            val h = (barVal * 42).dp
                                            Box(
                                                modifier = Modifier
                                                    .width(2.5.dp)
                                                    .height(if (segment.isSilence) 3.dp else h)
                                                    .clip(RoundedCornerShape(50))
                                                    .background(
                                                        if (segment.isExcluded) TextMuted.copy(alpha = 0.3f)
                                                        else when {
                                                            segment.isSilence -> NeonCoral
                                                            segment.isFiller -> ElectricViolet
                                                            segment.soundCategory == "LAUGHTER" -> Color(0xFFF59E0B)
                                                            else -> GlowCyan
                                                        }
                                                    )
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (duration > 2000) {
                                        Text(
                                            text = when {
                                                segment.isExcluded -> "✂️ Cut"
                                                segment.isSilence -> "🔇 Pause"
                                                segment.isFiller -> "🗣️ Filler"
                                                else -> "Scene #${segment.playOrder + 1}"
                                            },
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (segment.isExcluded) TextMuted else Color.White,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Seek Indicator Line overlays
                    val linePosition = trackWidth * (playheadPositionMs.toFloat() / project.videoDurationMs.toFloat().coerceAtLeast(1f))
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(2.dp)
                            .offset(x = linePosition)
                            .background(GlowCyan)
                    )
                }
            }
        }
    }

    // MANGA PANEL SELECTOR POPUP DIALOG
    if (showPanelSelectorDialog && dialogTargetSegment != null) {
        val activeTarget = dialogTargetSegment!!
        AlertDialog(
            onDismissRequest = { showPanelSelectorDialog = false },
            containerColor = SlateDark,
            title = {
                Text("Select Manga Panel Crop", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a cropped comic strip from internal storage to map into Scene #${activeTarget.playOrder + 1}.", fontSize = 11.sp, color = TextMuted)
                    
                    mockMangaPanels.forEach { panel ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(GraphiteSurface)
                                .clickable {
                                    viewModel.setMangaPanelImage(activeTarget, "manga_cache/${panel.name}.jpg")
                                    showPanelSelectorDialog = false
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(panel.color)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(panel.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(panel.desc, fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPanelSelectorDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            }
        )
    }
}

@Composable
fun StoryboardSceneCard(
    segment: TimelineSegment,
    isActive: Boolean,
    onPanelClick: () -> Unit,
    onExcludeToggle: () -> Unit,
    onSubtitleChange: (String) -> Unit,
    onMotionChange: (String, String, String) -> Unit,
    onWidescreenFillToggle: () -> Unit,
    onTransitionChange: (String) -> Unit
) {
    val durationSec = (segment.endMs - segment.startMs) / 1000.0
    var editedText by remember(segment.transcriptText) { mutableStateOf(segment.transcriptText ?: "") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isActive) GlowCyan else Color.Transparent, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) DarkCardBg else SlateDark.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Scene Card Header Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (segment.isSilence) NeonCoral.copy(alpha = 0.2f) else ElectricViolet.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (segment.isSilence) "PAUSE" else "SCENE #${segment.playOrder + 1}",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (segment.isSilence) NeonCoral else ElectricViolet
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = String.format("%.1fs - %.1fs (%.1fs)", segment.startMs / 1000.0, segment.endMs / 1000.0, durationSec),
                        fontSize = 9.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // 1-Tap Cut Toggle checkbox
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Exclude", fontSize = 9.sp, color = TextMuted, modifier = Modifier.padding(end = 2.dp))
                    Checkbox(
                        checked = segment.isExcluded,
                        onCheckedChange = { onExcludeToggle() },
                        colors = CheckboxDefaults.colors(
                            checkedColor = NeonCoral,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier.scale(0.7f)
                    )
                }
            }

            if (!segment.isSilence && !segment.isExcluded) {
                Spacer(modifier = Modifier.height(8.dp))

                // Mid row: Panel Loader placeholder & Text Editor
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Manga Panel selector visual box
                    val hasPanel = segment.panelImagePath != null
                    Box(
                        modifier = Modifier
                            .size(65.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(GraphiteSurface)
                            .border(1.dp, if (hasPanel) GlowCyan.copy(alpha = 0.5f) else TextMuted.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .clickable { onPanelClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (hasPanel) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(4.dp)) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = GlowCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Assigned", fontSize = 8.sp, color = TextPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text("Edit 🔄", fontSize = 7.sp, color = TextMuted)
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Add Panel", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Synced script transcriber inline text-field
                    Column(modifier = Modifier.weight(1f)) {
                        BasicTextField(
                            value = editedText,
                            onValueChange = {
                                editedText = it
                                onSubtitleChange(it)
                            },
                            textStyle = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(GraphiteSurface)
                                .padding(6.dp),
                            decorationBox = { innerTextField ->
                                if (editedText.isEmpty()) {
                                    Text("Narrated subtitle lines...", fontSize = 11.sp, color = TextMuted)
                                }
                                innerTextField()
                            }
                        )
                        Text("Edits sync instantly with playhead track subtitle blocks.", fontSize = 7.sp, color = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom configuration row: Camera AI movements and Transitions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // CAMERA MOVEMENT ACCENT SELECTOR
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Camera AI Panning", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(GraphiteSurface)
                                .clickable {
                                    // Cycles through camera pans on tap (2 taps concept)
                                    val nextMove = when (segment.cameraMotionType) {
                                        "Ken Burns" -> "Zoom In"
                                        "Zoom In" -> "Zoom Out"
                                        "Zoom Out" -> "Pan Left"
                                        "Pan Left" -> "Pan Right"
                                        else -> "Ken Burns"
                                    }
                                    onMotionChange(nextMove, segment.cameraMotionSpeed, segment.cameraFocusPoint)
                                }
                                .padding(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = GlowCyan, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(segment.cameraMotionType, fontSize = 8.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    // WIDESCREEN BLUR PRESET
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Widescreen Blur", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (segment.panelWidescreenFill) ElectricViolet.copy(alpha = 0.2f) else GraphiteSurface)
                                .border(1.dp, if (segment.panelWidescreenFill) ElectricViolet else Color.Transparent, RoundedCornerShape(4.dp))
                                .clickable { onWidescreenFillToggle() }
                                .padding(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AspectRatio, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (segment.panelWidescreenFill) "Dual-Blur On" else "No Sidebar", fontSize = 8.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    // TRANSITION ACCENT SELECTOR
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Scene Transition", fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(GraphiteSurface)
                                .clickable {
                                    // Cycles transitions on click
                                    val nextTransition = when (segment.transitionType) {
                                        "Fade" -> "Zoom"
                                        "Zoom" -> "Flash"
                                        "Flash" -> "Slide"
                                        "Slide" -> "None"
                                        else -> "Fade"
                                    }
                                    onTransitionChange(nextTransition)
                                }
                                .padding(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Transform, contentDescription = null, tint = GlowCyan, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(segment.transitionType, fontSize = 8.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (segment.isExcluded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.2f))
                        .padding(6.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text("✂️ Segment will be completely deleted from final exported media stream.", fontSize = 9.sp, color = NeonCoral, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

// Extension function to scale check boxes
@Composable
fun Modifier.scale(scale: Float): Modifier = this.graphicsLayer(scaleX = scale, scaleY = scale)

data class MangaPanelCrop(
    val name: String,
    val desc: String,
    val color: Color
)

fun formatTime(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}
