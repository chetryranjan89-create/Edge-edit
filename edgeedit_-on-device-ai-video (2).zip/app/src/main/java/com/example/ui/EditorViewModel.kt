package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.*
import com.example.data.*
import com.example.video.VideoEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val tag = "EditorViewModel"
    private val db = AppDatabase.getDatabase(application)
    private val repository = ProjectRepository(db.projectDao())
    private val videoEngine = VideoEngine(application)

    // Modular AI Agent instances
    val audioAgent: AudioAI = AudioAIImpl()
    val subtitleAgent: SubtitleAI = SubtitleAIImpl()
    val motionAgent: MotionAI = MotionAIImpl()
    val sceneAgent: SceneAI = SceneAIImpl()
    val panelAgent: PanelAI = PanelAIImpl()
    val exportAgent: ExportAI = ExportAIImpl()
    val performanceAgent: PerformanceAI = PerformanceAIImpl()
    val projectAgent: ProjectAI = ProjectAIImpl()

    // ----------------------------------------------------
    // STATE FLOWS
    // ----------------------------------------------------

    val projects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProjectId = MutableStateFlow<Int?>(null)
    val selectedProjectId: StateFlow<Int?> = _selectedProjectId.asStateFlow()
    
    val selectedProject: StateFlow<ProjectEntity?> = _selectedProjectId
        .flatMapLatest { id ->
            if (id != null) repository.getProject(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeSegments: StateFlow<List<TimelineSegment>> = _selectedProjectId
        .flatMapLatest { id ->
            if (id != null) repository.getSegments(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _waveformSamples = MutableStateFlow<List<Float>>(emptyList())
    val waveformSamples: StateFlow<List<Float>> = _waveformSamples.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playheadPositionMs = MutableStateFlow(0L)
    val playheadPositionMs: StateFlow<Long> = _playheadPositionMs.asStateFlow()

    private val _exportProgress = MutableStateFlow<Float?>(null)
    val exportProgress: StateFlow<Float?> = _exportProgress.asStateFlow()

    private val _exportMessage = MutableStateFlow("")
    val exportMessage: StateFlow<String> = _exportMessage.asStateFlow()

    private val _analysisProgress = MutableStateFlow<Float?>(null)
    val analysisProgress: StateFlow<Float?> = _analysisProgress.asStateFlow()

    private val _diagnosticProgress = MutableStateFlow<DiagnosticProgress?>(null)
    val diagnosticProgress: StateFlow<DiagnosticProgress?> = _diagnosticProgress.asStateFlow()

    private var playbackJob: Job? = null

    init {
        // Automatically pre-populate with premium manga projects on first install
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.allProjects.first()
            if (existing.isEmpty()) {
                val filesDir = getApplication<Application>().filesDir
                val voiceoverFile1 = File(filesDir, "demon_slayer_narration.mp3")
                if (!voiceoverFile1.exists()) {
                    voiceoverFile1.writeText("Demon Slayer Episode 5 narration vocal track.")
                }
                val voiceoverFile2 = File(filesDir, "solo_leveling_shorts.wav")
                if (!voiceoverFile2.exists()) {
                    voiceoverFile2.writeText("Solo leveling vertical youtube shorts.")
                }

                // Insert 1: Widescreen Manga Recap Project
                val id1 = repository.createProject(
                    name = "Demon Slayer: Ep 5 recap",
                    videoPath = voiceoverFile1.absolutePath,
                    durationMs = 42000L,
                    sizeBytes = 1240500L,
                    resolution = "1080p",
                    fps = 30,
                    aspectRatio = "16:9",
                    exportCodec = "H.264",
                    subtitleStyleId = 1,
                    templateId = "Manga Explanation"
                )
                initializeMockScenes(id1, 42000L, isVertical = false)

                // Insert 2: Vertical Manhwa Shorts Project
                val id2 = repository.createProject(
                    name = "Solo Leveling Chapter 180 Shorts",
                    videoPath = voiceoverFile2.absolutePath,
                    durationMs = 28000L,
                    sizeBytes = 852000L,
                    resolution = "1080p",
                    fps = 60,
                    aspectRatio = "9:16",
                    exportCodec = "H.265",
                    subtitleStyleId = 4,
                    templateId = "YouTube Shorts"
                )
                initializeMockScenes(id2, 28000L, isVertical = true)
            }
        }
    }

    private suspend fun initializeMockScenes(projectId: Int, durationMs: Long, isVertical: Boolean) {
        val rawSegments = sceneAgent.partitionNarration("", durationMs)
        val alignedSegments = subtitleAgent.generateSubtitles("", rawSegments)
        
        // Add default mock panels for representational purposes
        val mangaPhotos = if (isVertical) {
            listOf("panel_vert_1.jpg", "panel_vert_2.jpg", "panel_vert_3.jpg")
        } else {
            listOf("panel_wide_1.jpg", "panel_wide_2.jpg", "panel_wide_3.jpg")
        }

        val mapped = alignedSegments.mapIndexed { idx, segment ->
            if (!segment.isSilence) {
                segment.copy(
                    projectId = projectId,
                    panelImagePath = "/internal_storage/manga_cache/${mangaPhotos[idx % mangaPhotos.size]}",
                    panelWidescreenFill = !isVertical // Blur-fill for widescreen ratios
                )
            } else {
                segment.copy(projectId = projectId)
            }
        }
        repository.insertSegments(mapped)
        repository.updateProjectStatus(projectId, "Analyzed")
    }

    // ----------------------------------------------------
    // WORKSPACE OPERATIONS
    // ----------------------------------------------------

    fun selectProject(projectId: Int?) {
        _selectedProjectId.value = projectId
        _isPlaying.value = false
        playbackJob?.cancel()
        _playheadPositionMs.value = 0L

        if (projectId != null) {
            viewModelScope.launch(Dispatchers.IO) {
                val proj = repository.getProjectSync(projectId)
                if (proj != null) {
                    _waveformSamples.value = videoEngine.generateWaveform(proj.videoDurationMs, 120)
                }
            }
        } else {
            _waveformSamples.value = emptyList()
        }
    }

    fun importNarration(file: File, presetTemplate: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val preset = projectAgent.createDefaultTemplateConfig(presetTemplate)
            val durationMs = 30000L // 30 seconds average default for mock import
            
            val newId = repository.createProject(
                name = file.nameWithoutExtension.replace("_", " ").capitalize(),
                videoPath = file.absolutePath,
                durationMs = durationMs,
                sizeBytes = file.length(),
                resolution = preset.resolution,
                fps = 30,
                aspectRatio = preset.aspectRatio,
                exportCodec = if (preset.aspectRatio == "9:16") "H.265" else "H.264",
                subtitleStyleId = preset.subtitleStyleId,
                templateId = presetTemplate
            )
            
            // Automatically partition narration file via Scene AI in background
            runAIAnalysis(newId)
        }
    }

    fun createCustomProject(
        name: String,
        resolution: String,
        fps: Int,
        aspectRatio: String,
        codec: String,
        subtitleStyleId: Int,
        templateId: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val filesDir = getApplication<Application>().filesDir
            val mockFile = File(filesDir, "${name.lowercase().replace(" ", "_")}_rec.mp3")
            if (!mockFile.exists()) {
                mockFile.writeText("Custom recorded narration track.")
            }

            val newId = repository.createProject(
                name = name,
                videoPath = mockFile.absolutePath,
                durationMs = 35000L, // 35 seconds
                sizeBytes = mockFile.length().coerceAtLeast(12000L),
                resolution = resolution,
                fps = fps,
                aspectRatio = aspectRatio,
                exportCodec = codec,
                subtitleStyleId = subtitleStyleId,
                templateId = templateId
            )
            
            // Auto run analysis to split narration into scenic storyboards
            runAIAnalysis(newId)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (_selectedProjectId.value == project.id) {
                selectProject(null)
            }
            repository.deleteProject(project)
        }
    }

    // ----------------------------------------------------
    // PLAYBACK PREVIEW SYSTEMS
    // ----------------------------------------------------

    fun togglePlay() {
        val playing = !_isPlaying.value
        _isPlaying.value = playing

        if (playing) {
            startPlaybackSimulation()
        } else {
            playbackJob?.cancel()
        }
    }

    fun seekTo(positionMs: Long) {
        viewModelScope.launch {
            val proj = selectedProject.value ?: return@launch
            val bounded = positionMs.coerceIn(0L, proj.videoDurationMs)
            _playheadPositionMs.value = bounded
        }
    }

    private fun startPlaybackSimulation() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch(Dispatchers.Default) {
            val proj = selectedProject.value ?: return@launch
            var current = _playheadPositionMs.value
            val tickMs = 100L

            while (_isPlaying.value && current < proj.videoDurationMs) {
                kotlinx.coroutines.delay(tickMs)
                current += tickMs

                val segments = activeSegments.value
                val matchingSegment = segments.find { current >= it.startMs && current < it.endMs }
                
                // Skip silent / filler word sections automatically to maintain continuous clean output
                if (matchingSegment != null && matchingSegment.isExcluded) {
                    val nextActive = segments
                        .filter { it.startMs >= matchingSegment.endMs && !it.isExcluded }
                        .minByOrNull { it.startMs }
                    
                    if (nextActive != null) {
                        current = nextActive.startMs
                        Log.d(tag, "AI Jumpcut skipping muted segment: leaping to ${current}ms")
                    } else {
                        current = proj.videoDurationMs
                    }
                }

                _playheadPositionMs.value = current.coerceAtMost(proj.videoDurationMs)
                if (current >= proj.videoDurationMs) {
                    _isPlaying.value = false
                    _playheadPositionMs.value = 0L
                    break
                }
            }
        }
    }

    // ----------------------------------------------------
    // MANGA STORYBOARD ACTIONS (MINIMUM TAPS DESIGN)
    // ----------------------------------------------------

    fun setMangaPanelImage(segment: TimelineSegment, path: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(panelImagePath = path)
            repository.updateSegment(updated)
        }
    }

    fun duplicateMangaPanel3xCinematic(segment: TimelineSegment) {
        viewModelScope.launch(Dispatchers.IO) {
            // Enable duplicate-blur mode so widescreen frames fill margins automatically
            val updated = segment.copy(panelWidescreenFill = true)
            repository.updateSegment(updated)
        }
    }

    fun deleteMangaPanel(segment: TimelineSegment) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(panelImagePath = null)
            repository.updateSegment(updated)
        }
    }

    fun updateCameraMotion(segment: TimelineSegment, motionType: String, speed: String, focus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(
                cameraMotionType = motionType,
                cameraMotionSpeed = speed,
                cameraFocusPoint = focus
            )
            repository.updateSegment(updated)
        }
    }

    fun updateTransition(segment: TimelineSegment, transitionType: String, durationMs: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(
                transitionType = transitionType,
                transitionDurationMs = durationMs
            )
            repository.updateSegment(updated)
        }
    }

    fun toggleSegmentExclusion(segment: TimelineSegment) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(isExcluded = !segment.isExcluded)
            repository.updateSegment(updated)
        }
    }

    fun updateSegmentSubtitle(segment: TimelineSegment, newText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = segment.copy(transcriptText = newText)
            repository.updateSegment(updated)
        }
    }

    // ----------------------------------------------------
    // AUDIO ENGINE FILTERS (1-TAP ACTIONERS)
    // ----------------------------------------------------

    fun toggleAudioSetting(project: ProjectEntity, settingType: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = when (settingType) {
                "noise" -> project.copy(audioNoiseReduction = !project.audioNoiseReduction)
                "silence" -> project.copy(audioSilenceRemoval = !project.audioSilenceRemoval)
                "filler" -> project.copy(audioFillerRemoval = !project.audioFillerRemoval)
                "breath" -> project.copy(audioBreathReduction = !project.audioBreathReduction)
                "norm" -> project.copy(audioNormalization = !project.audioNormalization)
                "watermark" -> project.copy(watermarkToggle = !project.watermarkToggle)
                else -> project
            }
            repository.updateProject(updated)
            
            // If silence or filler cuts are updated, reflect onto segment exclusions
            if (settingType == "silence" || settingType == "filler") {
                syncAudioFilterExclusions(project.id, updated)
            }
        }
    }

    private suspend fun syncAudioFilterExclusions(projectId: Int, project: ProjectEntity) {
        val segments = repository.getSegmentsSync(projectId)
        segments.forEach { seg ->
            var shouldExclude = false
            if (project.audioSilenceRemoval && seg.isSilence) shouldExclude = true
            if (project.audioFillerRemoval && seg.isFiller) shouldExclude = true
            if (seg.isExcluded != shouldExclude) {
                repository.updateSegment(seg.copy(isExcluded = shouldExclude))
            }
        }
    }

    // ----------------------------------------------------
    // AI CO-PILOT ANALYSIS DRIVERS
    // ----------------------------------------------------

    fun runAIAnalysis(projectId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val proj = repository.getProjectSync(projectId) ?: return@launch
            _analysisProgress.value = 0.05f
            repository.updateProjectStatus(projectId, "Analyzing")
            
            _analysisProgress.value = 0.20f
            kotlinx.coroutines.delay(800) // loading speech models
            
            _analysisProgress.value = 0.50f
            val segments = videoEngine.analyzeVideoLocalAI(projectId, proj.videoDurationMs)
            
            _analysisProgress.value = 0.80f
            repository.recreateSegments(projectId, segments)
            repository.updateProjectStatus(projectId, "Analyzed")
            
            // Sync initial exclusions based on default project clean flags
            syncAudioFilterExclusions(projectId, proj)

            _analysisProgress.value = null
            selectProject(projectId)
        }
    }

    // ----------------------------------------------------
    // EXPORT RENDER ENGINES
    // ----------------------------------------------------

    fun exportMangaVideo() {
        val proj = selectedProject.value ?: return
        val segments = activeSegments.value
        
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateProjectStatus(proj.id, "Exporting")
            val outputDir = File(getApplication<Application>().filesDir, "exports")
            outputDir.mkdirs()
            val outputFile = File(outputDir, "manga_explanation_${proj.id}.mp4")

            videoEngine.exportVideoWithProgress(
                projectId = proj.id,
                videoPath = proj.videoPath,
                segments = segments,
                outputPath = outputFile.absolutePath,
                denoiseWithRNNoise = proj.audioNoiseReduction,
                gpuAcceleration = true
            ).collect { status ->
                _exportProgress.value = status.progress
                _exportMessage.value = status.message
            }

            repository.updateProjectStatus(proj.id, "Analyzed")
            _exportProgress.value = null
            _exportMessage.value = ""
        }
    }

    // ----------------------------------------------------
    // HARDWARE BENCHMARKS
    // ----------------------------------------------------

    fun runHardwareDiagnostics() {
        viewModelScope.launch(Dispatchers.Default) {
            performanceAgent.runHardwareDiagnostic().collect { diag ->
                _diagnosticProgress.value = diag
            }
        }
    }

    fun clearDiagnosticData() {
        _diagnosticProgress.value = null
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
    }
}
