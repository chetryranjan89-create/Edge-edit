package com.example.video

import java.io.Serializable

/**
 * Data class representing a recommended offline AI model for on-device execution.
 */
data class OfflineModel(
    val id: String,
    val name: String,
    val category: String,
    val targetTask: String,
    val filename: String,
    val modelFormat: String, // TFLite, ONNX, ML Kit
    val sizeMb: Double,
    val ramRequiredMb: Int,
    val averageInferenceMs: Int,
    val whyChosen: String,
    val efficiencyOnAndroid: String
) : Serializable

object LocalAIModels {
    
    val RECOMMENDED_MODELS = listOf(
        OfflineModel(
            id = "whisper_tiny",
            name = "OpenAI Whisper Tiny (English)",
            category = "Speech Recognition & Subtitles",
            targetTask = "Auto captions, subtitles, auto chaptering, and filler word detection",
            filename = "whisper-tiny-en.tflite",
            modelFormat = "TFLite (FP16 quantized)",
            sizeMb = 75.0,
            ramRequiredMb = 120,
            averageInferenceMs = 150,
            whyChosen = "Whisper provides world-class offline speech-to-text accuracy. By using the 'Tiny' model quantized to FP16, we maintain a word-error-rate (WER) comparable to cloud APIs while dramatically reducing size.",
            efficiencyOnAndroid = "Runs extremely fast using the TensorFlow Lite GPU delegate or NNAPI (Neural Networks API). It processes 10 seconds of audio in less than 1.5 seconds on modern mid-range devices."
        ),
        OfflineModel(
            id = "silero_vad",
            name = "Silero VAD v4",
            category = "Voice Activity Detection (VAD)",
            targetTask = "Detecting silence, awkward pauses, and pacing adjustments",
            filename = "silero_vad.onnx",
            modelFormat = "ONNX Runtime Mobile",
            sizeMb = 1.8,
            ramRequiredMb = 15,
            averageInferenceMs = 1,
            whyChosen = "The industry standard for ultra-lightweight offline Voice Activity Detection. It outperforms classical energy-threshold algorithms (like WebRTC VAD) in noisy environments and consumes virtually no space.",
            efficiencyOnAndroid = "Its stateful LSTM architecture maintains context across audio frames. At a 1.8MB file size, it fits entirely in L3 CPU cache, requiring less than 2% CPU usage per audio thread."
        ),
        OfflineModel(
            id = "yamnet_audio",
            name = "YAMNet Sound Classifier",
            category = "Audio Event & Emotion Detection",
            targetTask = "Detecting laughter, excitement, sighing, and background noise levels",
            filename = "yamnet.tflite",
            modelFormat = "TFLite (INT8 quantized)",
            sizeMb = 3.7,
            ramRequiredMb = 25,
            averageInferenceMs = 8,
            whyChosen = "YAMNet is an audio classification network pre-trained on AudioSet, capable of recognizing 521 audio events. It perfectly identifies 'laughter', 'screaming', 'cheering', or 'sigh' to index highlights and emotions.",
            efficiencyOnAndroid = "Fully quantized to 8-bit integers. It can run continuously in a background worker, processing audio streams in chunks of 975ms with minimal power consumption."
        ),
        OfflineModel(
            id = "ecapa_tdnn",
            name = "ECAPA-TDNN Speaker Embeddings",
            category = "Speaker Detection (Diarization)",
            targetTask = "Distinguishing between speakers, cutting other speakers, or prioritizing host voice",
            filename = "ecapa_tdnn.onnx",
            modelFormat = "ONNX Runtime Mobile",
            sizeMb = 22.0,
            ramRequiredMb = 60,
            averageInferenceMs = 45,
            whyChosen = "Computes high-quality voice embeddings (x-vectors) that represent unique vocal tracts. This lets us group speech segments by distinct speakers entirely on-device.",
            efficiencyOnAndroid = "Optimized with 1D dilated depthwise convolutions. Utilizing ONNX Runtime's FP16 execution on mobile, it extracts speaker fingerprints with near-instantaneous latency."
        ),
        OfflineModel(
            id = "mobilenet_v4_scene",
            name = "MobileNetV4 Scene Detector",
            category = "Scene Detection & Visual Quality",
            targetTask = "Detecting scene cuts, visual blur, camera shake, and duplicate frames",
            filename = "mobilenet_v4_lite_scene.tflite",
            modelFormat = "TFLite",
            sizeMb = 12.5,
            ramRequiredMb = 45,
            averageInferenceMs = 12,
            whyChosen = "MobileNetV4 leverages Hardware-Aware AutoML designed for mobile processors. By extracting spatial feature maps, we detect changes in camera angles (scene boundaries) and calculate frame clarity (blur detection).",
            efficiencyOnAndroid = "Directly binds to the Android GPU delegate. It can sample video frames at 10 FPS during background analysis to avoid thermal throttling while rendering cuts."
        ),
        OfflineModel(
            id = "ml_kit_ocr",
            name = "Google ML Kit Text Recognition",
            category = "Optical Character Recognition (OCR)",
            targetTask = "Extracting video text, identifying slides/titles, and matching key terms",
            filename = "Dynamic Play Services Library",
            modelFormat = "ML Kit (On-device API)",
            sizeMb = 0.0, // Managed by system
            ramRequiredMb = 30,
            averageInferenceMs = 90,
            whyChosen = "Google ML Kit Text Recognition is 100% free, runs locally, and is supported natively by Android. It detects text orientations, bounding boxes, and paragraphs instantly without expanding the app's size.",
            efficiencyOnAndroid = "By offloading the model weights to Google Play Services, the app's download size remains untouched. It runs utilizing high-performance native NNAPI drivers built by OEMs."
        )
    )
}
