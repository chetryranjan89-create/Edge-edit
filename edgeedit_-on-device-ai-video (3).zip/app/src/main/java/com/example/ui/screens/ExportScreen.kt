package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.EditorViewModel
import com.example.ui.theme.*
import java.io.File

@Composable
fun ExportScreen(
    viewModel: EditorViewModel,
    modifier: Modifier = Modifier
) {
    val selectedProject by viewModel.selectedProject.collectAsState()
    val exportProgress by viewModel.exportProgress.collectAsState()
    val exportMessage by viewModel.exportMessage.collectAsState()

    var isExportComplete by remember { mutableStateOf(false) }
    var exportedFileSize by remember { mutableStateOf("") }
    var exportedPath by remember { mutableStateOf("") }

    // Identify export completions
    LaunchedEffect(exportProgress) {
        if (exportProgress == 1.0f) {
            isExportComplete = true
            val filesDir = selectedProject?.videoPath?.let { File(it).parentFile }
            val dummyFile = File(filesDir, "exports/manga_explanation_${selectedProject?.id ?: 1}.mp4")
            exportedPath = dummyFile.absolutePath
            
            // Calculate size estimation from Export AI agent
            val project = selectedProject
            if (project != null) {
                val bytes = viewModel.exportAgent.estimateExportSize(project.resolution, project.fps, project.exportCodec, project.videoDurationMs)
                exportedFileSize = String.format("%.2f MB", bytes / (1024.0 * 1024.0))
            } else {
                exportedFileSize = "8.40 MB"
            }
        } else if (exportProgress != null && exportProgress!! < 1.0f) {
            isExportComplete = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDark)
            .padding(16.dp)
    ) {
        Text(
            text = "Render & Export",
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Compile your narrative storyboard cards into a cohesive mp4 recap video.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (selectedProject == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GraphiteSurface)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MovieCreation, contentDescription = "Empty", tint = TextMuted, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No Active Project Selected", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Load or create a project on the Projects tab first.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        } else {
            val project = selectedProject!!

            if (exportProgress != null) {
                // EXPORTING STATE SCREEN
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GraphiteSurface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                progress = { exportProgress!! },
                                modifier = Modifier.size(130.dp).testTag("export_progress_indicator"),
                                color = ElectricViolet,
                                strokeWidth = 8.dp,
                                trackColor = SlateDark
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${(exportProgress!! * 100).toInt()}%", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text("RENDERING", fontSize = 10.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SlateDark)
                                .border(1.dp, ElectricViolet.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(exportMessage, fontSize = 11.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text("Utilizing on-device MediaCodec hardware encoders. Do not lock screen.", fontSize = 10.sp, color = TextMuted)
                    }
                }
            } else if (isExportComplete) {
                // COMPLETE SCREEN
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GraphiteSurface)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color(0xFF10B981), modifier = Modifier.size(36.dp))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Render Node Execution Success!", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("Your comic narration video is fully compiled offline.", fontSize = 11.sp, color = TextMuted)

                    Spacer(modifier = Modifier.height(18.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SlateDark)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportMetadataItem(label = "Output Container", value = "MPEG-4 (.mp4)")
                        ExportMetadataItem(label = "Codec Profile", value = "${project.exportCodec} High Profile")
                        ExportMetadataItem(label = "Aspect Ratio", value = "${project.aspectRatio} (${project.resolution})")
                        ExportMetadataItem(label = "Output File Size", value = exportedFileSize)
                        ExportMetadataItem(label = "Disk Path", value = "internal_storage/exports/manga_explanation_${project.id}.mp4")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { isExportComplete = false },
                            colors = ButtonDefaults.buttonColors(containerColor = GraphiteSurface),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, TextMuted.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Render Again", color = TextPrimary)
                        }

                        Button(
                            onClick = { /* Share Simulation */ },
                            colors = ButtonDefaults.buttonColors(containerColor = GlowCyan),
                            modifier = Modifier.weight(1f).testTag("share_video_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = SlateDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share File", color = SlateDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // CONFIGURATION / SECTIONS COMPILE HUB
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GraphiteSurface)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("PRE-RENDER AI CALIBRATIONS", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontWeight = FontWeight.Bold)

                        // Info cards
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SlateDark)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = GlowCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Automated Audio Cleaning Active", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text("The render pipeline will apply your toggled dsp filters (denoising, vocal compression, soundtrack ducking) directly.", fontSize = 9.sp, color = TextMuted)
                            }
                        }

                        // Codec card info
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SlateDark)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Hardware Encoding", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text("Encoding with ${project.exportCodec} MediaCodec hardware bindings at ${project.fps}fps.", fontSize = 9.sp, color = TextMuted)
                            }
                        }

                        // Estimations card
                        Text("OFFLINE SIZE & TIME ESTIMATORS", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontWeight = FontWeight.Bold)

                        val estimatedBytes = viewModel.exportAgent.estimateExportSize(project.resolution, project.fps, project.exportCodec, project.videoDurationMs)
                        val estimatedTimeSec = viewModel.exportAgent.estimateExportTime(project.resolution, project.fps, project.exportCodec, project.videoDurationMs)
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SlateDark)
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Text("Estimated File Size", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                                    Text(String.format("%.2f MB", estimatedBytes / (1024.0 * 1024.0)), fontSize = 14.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                    Text("Fits perfectly on mobile", fontSize = 8.sp, color = TextMuted)
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SlateDark)
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Text("Estimated Render Time", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                                    Text("${estimatedTimeSec} seconds", fontSize = 14.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                                    Text("Powered by hardware GPU", fontSize = 8.sp, color = TextMuted)
                                }
                            }
                        }
                    }

                    // Export Trigger button
                    Button(
                        onClick = { viewModel.exportMangaVideo() },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("render_video_button")
                    ) {
                        Icon(Icons.Default.Publish, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RENDER OFFLINE EXPORT", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ExportMetadataItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Text(value, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
}
