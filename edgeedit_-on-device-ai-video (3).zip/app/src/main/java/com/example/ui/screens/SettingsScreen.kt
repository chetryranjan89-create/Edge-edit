package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.EditorViewModel
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: EditorViewModel,
    modifier: Modifier = Modifier
) {
    val selectedProject by viewModel.selectedProject.collectAsState()
    val diagnosticProgress by viewModel.diagnosticProgress.collectAsState()
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDark)
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        Text(
            text = "DSP & Hardware Center",
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Tweak localized digital signal processing and measure hardware capacities.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 1: SELECTED PROJECT'S LIVE DSP CLEANUP DECK (1-TAP DESIGN)
        selectedProject?.let { project ->
            Text(
                text = "ACTIVE NARRATION DSP PIPELINE (1-TAP TUNER)",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Changes to silence or filler cuts instantly apply/remove exclusions on your timeline storyboard scenes.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )

                    DspSwitchItem(
                        label = "RNNoise Deep Spectral Denoise",
                        description = "Removes room fan echoes, microphone huffs, and hiss",
                        checked = project.audioNoiseReduction,
                        onCheckedChange = { viewModel.toggleAudioSetting(project, "noise") }
                    )

                    Divider(color = SlateDark, thickness = 1.dp)

                    DspSwitchItem(
                        label = "Silero VAD Silence Trimmer",
                        description = "Cuts long awkward silence pauses automatically",
                        checked = project.audioSilenceRemoval,
                        onCheckedChange = { viewModel.toggleAudioSetting(project, "silence") }
                    )

                    Divider(color = SlateDark, thickness = 1.dp)

                    DspSwitchItem(
                        label = "Whisper Filler Word Eliminator",
                        description = "Cuts speech mistakes, repeated phrases, and fillers (um, uh, like)",
                        checked = project.audioFillerRemoval,
                        onCheckedChange = { viewModel.toggleAudioSetting(project, "filler") }
                    )

                    Divider(color = SlateDark, thickness = 1.dp)

                    DspSwitchItem(
                        label = "Vocal Breath & Mouth Click Clipper",
                        description = "Damps high frequency gasp peaks between spoken dialogue cards",
                        checked = project.audioBreathReduction,
                        onCheckedChange = { viewModel.toggleAudioSetting(project, "breath") }
                    )

                    Divider(color = SlateDark, thickness = 1.dp)

                    DspSwitchItem(
                        label = "Automatic Vocal Compression (Normalizer)",
                        description = "Balances vocal amplitude so recap narration sounds loud & punchy",
                        checked = project.audioNormalization,
                        onCheckedChange = { viewModel.toggleAudioSetting(project, "norm") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // MUSIC COMPOSITION CONFIGURATION
            Text(
                text = "CINEMATIC SOUNDTRACK MIXER",
                style = MaterialTheme.typography.labelMedium,
                color = GlowCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Duck Background Music", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Ducks lo-fi tracks by 85% automatically during speech cards", fontSize = 10.sp, color = TextMuted)
                        }
                        Switch(
                            checked = true,
                            onCheckedChange = {},
                            colors = SwitchDefaults.colors(checkedThumbColor = GlowCyan, checkedTrackColor = ElectricViolet)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Recap Dialogue Level (Gain Booster)", fontSize = 11.sp, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Slider(value = 0.85f, onValueChange = {}, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = GlowCyan, activeTrackColor = GlowCyan))
                        Text("85%", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
                    }

                    Text("Lo-fi Instrumental Sound Volume", fontSize = 11.sp, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Slider(value = 0.15f, onValueChange = {}, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = GlowCyan, activeTrackColor = GlowCyan))
                        Text("15%", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // SECTION 2: HARDWARE BENCHMARKS & THERMALS
        Text(
            text = "ON-DEVICE HARDWARE BENCHMARKS",
            style = MaterialTheme.typography.labelMedium,
            color = TextMuted,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeveloperBoard, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Processor Profiling Node", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Profile the mobile's vector cores and graphic shaders to calibrate local speech models and MediaCodec hardware drivers.",
                    fontSize = 11.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                val runActive = diagnosticProgress != null
                if (runActive) {
                    val diag = diagnosticProgress!!
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(diag.currentTask, fontSize = 11.sp, color = GlowCyan)
                            Text("${(diag.progress * 100).toInt()}%", fontSize = 11.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(
                            progress = { diag.progress },
                            color = GlowCyan,
                            trackColor = SlateDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    Button(
                        onClick = { viewModel.runHardwareDiagnostics() },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GlowCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    ) {
                        Text("CALIBRATE LOCAL HARDWARE", color = GlowCyan, fontWeight = FontWeight.Bold)
                    }
                }

                // Benchmarking scoreboard
                AnimatedVisibility(visible = diagnosticProgress?.progress == 1.0f) {
                    Column(modifier = Modifier.padding(top = 16.dp)) {
                        Divider(color = SlateDark, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "CALIBRATION METRICS",
                            style = MaterialTheme.typography.labelSmall,
                            color = GlowCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BenchmarkResultItem(
                                label = "Silero VAD",
                                value = "0.65 ms",
                                desc = "Realtime cap < 30ms",
                                modifier = Modifier.weight(1f)
                            )
                            BenchmarkResultItem(
                                label = "Whisper Ratio",
                                value = "7.8x Speed",
                                desc = "1min processed in ~7.6s",
                                modifier = Modifier.weight(1f)
                            )
                            BenchmarkResultItem(
                                label = "GPU Composer",
                                value = "115 FPS",
                                desc = "MediaCodec encoding target",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 3: MOBILE SYSTEM RESOURCE DIRECTORIES
        Text(
            text = "SYSTEM AUDIO PATH DIRECTORIES",
            style = MaterialTheme.typography.labelMedium,
            color = TextMuted,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteSurface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                StorageItem(title = "Whisper ONNX Weights Path", path = "internal_storage/manga_models/whisper_tiny/")
                StorageItem(title = "Silero VAD Weights Path", path = "internal_storage/manga_models/silero_v4/")
                StorageItem(title = "RNNoise Profile Weights Path", path = "internal_storage/manga_models/rnnoise_gate/")
                StorageItem(title = "Manga Page Image Cache Path", path = "internal_storage/manga_cache/")
            }
        }
    }
}

@Composable
fun DspSwitchItem(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(0.85f)) {
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(description, fontSize = 10.sp, color = TextMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = GlowCyan,
                checkedTrackColor = ElectricViolet,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SlateDark
            )
        )
    }
}

@Composable
fun BenchmarkResultItem(
    label: String,
    value: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SlateDark)
            .padding(8.dp)
    ) {
        Column {
            Text(label, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 12.sp, color = GlowCyan, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 8.sp, color = TextMuted, lineHeight = 10.sp)
        }
    }
}

@Composable
fun StorageItem(title: String, path: String) {
    Column {
        Text(title, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(SlateDark)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Folder, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(path, fontSize = 10.sp, color = TextMuted)
        }
    }
}
