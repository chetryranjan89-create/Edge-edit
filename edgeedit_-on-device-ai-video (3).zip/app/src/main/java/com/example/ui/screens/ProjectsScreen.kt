package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProjectEntity
import com.example.ui.EditorViewModel
import com.example.ui.theme.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProjectsScreen(
    viewModel: EditorViewModel,
    onProjectSelected: () -> Unit,
    onCreateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val projects by viewModel.projects.collectAsState()
    val selectedProject by viewModel.selectedProject.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    
    // Dialog control states
    var projectToRename by remember { mutableStateOf<ProjectEntity?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var showRenameDialog by remember { mutableStateOf(false) }

    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val filteredProjects = remember(projects, searchQuery) {
        if (searchQuery.isBlank()) {
            projects
        } else {
            projects.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDark),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // HEADER ROW & STATS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Projects Workspace",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Manage and backup local recaps",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
                
                Button(
                    onClick = onCreateClick,
                    colors = ButtonDefaults.buttonColors(containerColor = GlowCyan),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New", tint = SlateDark, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Project", color = SlateDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        // COMPACT SEARCH BAR & BACKUP ACTIONS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search projects...", fontSize = 12.sp) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(16.dp), tint = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GlowCyan,
                        unfocusedBorderColor = GraphiteSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    textStyle = MaterialTheme.typography.bodySmall
                )

                // IMPORT JSON BACKUP BUTTON
                IconButton(
                    onClick = {
                        // Simulate importing a local JSON backup file
                        Toast.makeText(context, "Scanning local storage for project backups...", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(GraphiteSurface)
                ) {
                    Icon(Icons.Default.Input, "Import Project File", tint = GlowCyan, modifier = Modifier.size(18.dp))
                }
            }
        }

        if (filteredProjects.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No projects match your query", fontSize = 12.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // COMPACT EDITING LIST ITEMS (NO BULKY CARDS)
            items(filteredProjects) { project ->
                val isActive = selectedProject?.id == project.id
                val df = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
                val dateStr = remember(project.createdAt) { df.format(Date(project.createdAt)) }
                val durationStr = remember(project.videoDurationMs) {
                    val sec = (project.videoDurationMs / 1000) % 60
                    val min = (project.videoDurationMs / 60000) % 60
                    String.format("%02d:%02d", min, sec)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (isActive) GlowCyan else Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable {
                            viewModel.selectProject(project.id)
                            onProjectSelected() // Shift directly to Editor Workspace
                        },
                    colors = CardDefaults.cardColors(containerColor = if (isActive) DarkCardBg else GraphiteSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // ASPECT RATIO COMPACT BADGE
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SlateDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (project.aspectRatio) {
                                    "9:16" -> Icons.Default.PhoneAndroid
                                    "1:1" -> Icons.Default.CropSquare
                                    else -> Icons.Default.Tv
                                },
                                contentDescription = null,
                                tint = if (isActive) GlowCyan else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // CORE INFO BLOCK
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = project.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(ElectricViolet.copy(alpha = 0.2f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = project.aspectRatio,
                                        color = ElectricViolet,
                                        fontSize = 7.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("⏱️ $durationStr", fontSize = 9.sp, color = TextMuted)
                                Text("🎬 ${project.resolution}", fontSize = 9.sp, color = TextMuted)
                                Text(dateStr, fontSize = 9.sp, color = TextMuted)
                                Text(
                                    text = "• ${project.status}",
                                    fontSize = 9.sp,
                                    color = if (project.status == "Analyzed") Color(0xFF10B981) else TextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // CONVENIENT CONTEXT ACTIONS ROW
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Backup project config button
                            IconButton(
                                onClick = {
                                    // Backup config
                                    Toast.makeText(context, "Exported project JSON to internal/backups/${project.name.lowercase().replace(" ", "_")}.json", Toast.LENGTH_LONG).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Output, "Backup Project", tint = GlowCyan.copy(alpha = 0.7f), modifier = Modifier.size(15.dp))
                            }

                            // Rename button
                            IconButton(
                                onClick = {
                                    projectToRename = project
                                    renameValue = project.name
                                    showRenameDialog = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Edit, "Rename", tint = TextMuted, modifier = Modifier.size(15.dp))
                            }

                            // Delete button
                            IconButton(
                                onClick = {
                                    projectToDelete = project
                                    showDeleteConfirm = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Delete, "Delete", tint = NeonCoral.copy(alpha = 0.8f), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // RENAME DIALOG
    if (showRenameDialog && projectToRename != null) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            containerColor = SlateDark,
            title = { Text("Rename Project", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GlowCyan,
                        unfocusedBorderColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val original = projectToRename!!
                        val newName = renameValue.trim()
                        if (newName.isNotEmpty()) {
                            viewModel.updateProjectSettings(original.copy(name = newName))
                        }
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GlowCyan)
                ) {
                    Text("Rename", color = SlateDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            }
        )
    }

    // DELETE CONFIRMATION DIALOG
    if (showDeleteConfirm && projectToDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = SlateDark,
            title = { Text("Confirm Deletion", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Text(
                    text = "Are you sure you want to permanently delete project '${projectToDelete!!.name}'? This action cannot be undone and will delete all assigned storyboard panels and subtitle timings.",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteProject(projectToDelete!!)
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCoral)
                ) {
                    Text("Permanently Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = TextMuted)
                }
            }
        )
    }
}
