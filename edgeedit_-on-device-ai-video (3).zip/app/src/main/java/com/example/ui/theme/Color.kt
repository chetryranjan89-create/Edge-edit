package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Slate Dark Theme Colors
val SlateDark = Color(0xFF0A0C14)
val GraphiteSurface = Color(0xFF141724)
val DarkCardBg = Color(0xFF1E2235)

val ElectricViolet = Color(0xFF8B5CF6)
val GlowCyan = Color(0xFF06B6D4)
val NeonCoral = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)

val CutSegmentColor = Color(0x33F43F5E) // Red tint for trimmed sections
val KeepSegmentColor = Color(0x3306B6D4) // Cyan tint for speech
val HighlightSegmentColor = Color(0x3310B981) // Green tint for highlights
val LaughterSegmentColor = Color(0x33F59E0B) // Amber tint for laughter
val FillerSegmentColor = Color(0x338B5CF6) // Purple tint for filler words

