package com.example.data

import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun getProject(projectId: Int): Flow<ProjectEntity?> {
        return projectDao.getProjectById(projectId)
    }

    suspend fun getProjectSync(projectId: Int): ProjectEntity? {
        return projectDao.getProjectByIdSync(projectId)
    }

    fun getSegments(projectId: Int): Flow<List<TimelineSegment>> {
        return projectDao.getSegmentsForProject(projectId)
    }

    suspend fun getSegmentsSync(projectId: Int): List<TimelineSegment> {
        return projectDao.getSegmentsForProjectSync(projectId)
    }

    suspend fun createProject(
        name: String,
        videoPath: String,
        durationMs: Long,
        sizeBytes: Long,
        resolution: String = "1080p",
        fps: Int = 30,
        aspectRatio: String = "16:9",
        exportCodec: String = "H.264",
        subtitleStyleId: Int = 1,
        templateId: String = "Manga Explanation"
    ): Int {
        val project = ProjectEntity(
            name = name,
            videoPath = videoPath,
            videoDurationMs = durationMs,
            videoSizeByte = sizeBytes,
            resolution = resolution,
            fps = fps,
            aspectRatio = aspectRatio,
            exportCodec = exportCodec,
            subtitleStyleId = subtitleStyleId,
            templateId = templateId,
            createdAt = System.currentTimeMillis(),
            lastModifiedAt = System.currentTimeMillis()
        )
        return projectDao.insertProject(project).toInt()
    }

    suspend fun updateProject(project: ProjectEntity) {
        projectDao.updateProject(project.copy(lastModifiedAt = System.currentTimeMillis()))
    }

    suspend fun updateProjectStatus(projectId: Int, status: String) {
        projectDao.updateProjectStatus(projectId, status)
    }

    suspend fun insertSegments(segments: List<TimelineSegment>) {
        projectDao.insertSegments(segments)
    }

    suspend fun updateSegment(segment: TimelineSegment) {
        projectDao.updateSegment(segment)
    }

    suspend fun recreateSegments(projectId: Int, segments: List<TimelineSegment>) {
        projectDao.deleteSegmentsForProject(projectId)
        // Re-bind all segments to this specific project ID
        val boundSegments = segments.map { it.copy(projectId = projectId) }
        projectDao.insertSegments(boundSegments)
        projectDao.updateProjectAnalysisStatus(projectId, hasBeenAnalyzed = true)
    }

    suspend fun deleteProject(project: ProjectEntity) {
        projectDao.deleteSegmentsForProject(project.id)
        projectDao.deleteProject(project)
    }
}
