package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Query("SELECT * FROM projects ORDER BY lastModifiedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :projectId")
    fun getProjectById(projectId: Int): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :projectId")
    suspend fun getProjectByIdSync(projectId: Int): ProjectEntity?

    @Query("SELECT * FROM timeline_segments WHERE projectId = :projectId ORDER BY playOrder ASC")
    fun getSegmentsForProject(projectId: Int): Flow<List<TimelineSegment>>

    @Query("SELECT * FROM timeline_segments WHERE projectId = :projectId ORDER BY playOrder ASC")
    suspend fun getSegmentsForProjectSync(projectId: Int): List<TimelineSegment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("UPDATE projects SET status = :status WHERE id = :projectId")
    suspend fun updateProjectStatus(projectId: Int, status: String)

    @Query("UPDATE projects SET hasBeenAnalyzed = :hasBeenAnalyzed WHERE id = :projectId")
    suspend fun updateProjectAnalysisStatus(projectId: Int, hasBeenAnalyzed: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSegments(segments: List<TimelineSegment>)

    @Update
    suspend fun updateSegment(segment: TimelineSegment)

    @Query("DELETE FROM timeline_segments WHERE projectId = :projectId")
    suspend fun deleteSegmentsForProject(projectId: Int)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)
}
