package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val videoPath: String, // Serves as raw audio/narration file path in Manga context
    val videoDurationMs: Long,
    val videoSizeByte: Long,
    val thumbnailPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val lastModifiedAt: Long = System.currentTimeMillis(),
    val hasBeenAnalyzed: Boolean = false,
    val status: String = "Idle", // Idle, Analyzing, Analyzed, Exporting
    
    // Manga Explanation format configurations
    val resolution: String = "1080p",         // 720p, 1080p, 1440p, 4K
    val fps: Int = 30,                         // 24, 30, 60
    val aspectRatio: String = "16:9",          // 16:9, 9:16, 1:1
    val exportCodec: String = "H.264",         // H.264, H.265
    val subtitleStyleId: Int = 1,              // Preset 1 to 6
    val templateId: String = "Manga Explanation", // Template type selection
    
    // On-Device Audio cleaning controls
    val audioNoiseReduction: Boolean = true,
    val audioSilenceRemoval: Boolean = true,
    val audioFillerRemoval: Boolean = true,
    val audioBreathReduction: Boolean = true,
    val audioNormalization: Boolean = true,
    
    // Integrated Background audio
    val bgMusicPath: String? = null,
    val bgMusicVolume: Float = 0.15f,
    val watermarkToggle: Boolean = false
) : Serializable

@Entity(tableName = "timeline_segments")
data class TimelineSegment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val startMs: Long,
    val endMs: Long,
    val playOrder: Int,
    val isSilence: Boolean = false,
    val isFiller: Boolean = false,
    val isExcluded: Boolean = false,
    val transcriptText: String? = null,
    val type: String = "NORMAL", // NORMAL, SILENCE, FILLER
    val soundCategory: String = "SPEECH", // SPEECH, LAUGHTER, NOISE
    
    // VISUALS: Selected Manga Panel Details for this Scene Card
    val panelImagePath: String? = null,       // Path to local manga page crop or panel image
    val panelRotation: Float = 0f,            // 0, 90, 180, 270 degrees
    val panelZoom: Float = 1.0f,              // Manual scale offset
    val panelWidescreenFill: Boolean = true,   // True: duplicates and blurs margins to fill widescreen aspect ratio
    
    // CAMERA AI: Automated Ken Burns Movements for this scene
    val cameraMotionType: String = "Ken Burns", // Ken Burns, Zoom In, Zoom Out, Pan Left, Pan Right, None
    val cameraMotionSpeed: String = "Medium",  // Slow, Medium, Fast
    val cameraShakeIntensity: Float = 0.0f,    // Rumble action scale (0.0 to 1.0)
    val cameraFocusPoint: String = "Center",   // Center, Top, Bottom, Speech Bubble, Character
    
    // TRANSITIONS: Automatics scene changes
    val transitionType: String = "Fade",       // Fade, Crossfade, Flash, Slide, Blur, Zoom, Scale, Push, Whip, None
    val transitionDurationMs: Int = 500,
    
    // SUBTITLES: Local Word Timings metadata (Format: word|startMs|endMs;word|...)
    val subText: String? = null
) : Serializable
