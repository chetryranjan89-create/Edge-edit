package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.EditorViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppLayout()
            }
        }
    }
}

@Composable
fun MainAppLayout() {
    val viewModel: EditorViewModel = viewModel()
    var activeTab by remember { mutableStateOf(0) }
    
    val selectedProject by viewModel.selectedProject.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    val tabs = listOf(
        NavigationTabItem("Home", Icons.Default.Home, "home_tab"),
        NavigationTabItem("Projects", Icons.Default.FolderOpen, "projects_tab"),
        NavigationTabItem("Editor", Icons.Default.ContentCut, "editor_tab"),
        NavigationTabItem("Export", Icons.Default.Publish, "render_tab"),
        NavigationTabItem("Settings", Icons.Default.Settings, "settings_tab")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = GraphiteSurface,
                modifier = Modifier.testTag("app_navigation_bar")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SlateDark,
                            selectedTextColor = GlowCyan,
                            indicatorColor = GlowCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = SlateDark
        ) {
            when (activeTab) {
                0 -> HomeScreen(
                    viewModel = viewModel,
                    onCreateProjectClick = { showCreateDialog = true },
                    onProjectSelect = { proj ->
                        viewModel.selectProject(proj.id)
                        activeTab = 2 // Shift directly to Editor Workspace
                    }
                )
                1 -> ProjectsScreen(
                    viewModel = viewModel,
                    onProjectSelected = { activeTab = 2 }, // Jump directly to Editor Workspace!
                    onCreateClick = { showCreateDialog = true }
                )
                2 -> EditorScreen(
                    viewModel = viewModel
                )
                3 -> ExportScreen(
                    viewModel = viewModel
                )
                4 -> SettingsScreen(
                    viewModel = viewModel
                )
            }
        }
    }

    // SHARED CREATE EMPTY PROJECT DIALOG
    if (showCreateDialog) {
        var projectName by remember { mutableStateOf("") }
        var selectedRatio by remember { mutableStateOf("16:9") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = SlateDark,
            title = {
                Text(
                    text = "Create New Project",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Enter your project details to create a fresh, clean storyboard. No preloaded stories, no mock characters.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )

                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Project Name") },
                        placeholder = { Text("My Anime Storyboard Recap") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GlowCyan,
                            unfocusedBorderColor = TextMuted,
                            focusedLabelColor = GlowCyan,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Video Aspect Ratio",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GlowCyan
                    )

                    val ratios = listOf(
                        AspectRatioOption("16:9", "16:9 YouTube", Icons.Default.Tv),
                        AspectRatioOption("9:16", "9:16 Shorts/Reels", Icons.Default.PhoneAndroid),
                        AspectRatioOption("1:1", "1:1 Square", Icons.Default.CropSquare)
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ratios.forEach { option ->
                            val isSelected = selectedRatio == option.value
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) ElectricViolet.copy(alpha = 0.3f) else GraphiteSurface)
                                    .clickable { selectedRatio = option.value }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = option.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) GlowCyan else TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = option.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) TextPrimary else TextMuted
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = projectName.trim().ifEmpty { "New Storyboard Recap" }
                        viewModel.createCustomProject(name, selectedRatio)
                        showCreateDialog = false
                        activeTab = 2 // Switch active tab automatically to Editor Screen!
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GlowCyan)
                ) {
                    Text("Create Empty Project", color = SlateDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            }
        )
    }
}

data class AspectRatioOption(
    val value: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

data class NavigationTabItem(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)
