package com.example.ai

import com.example.data.TimelineSegment
import kotlinx.coroutines.flow.Flow
import java.io.File

/**
 * 1. AUDIO AI AGENT
 * Cleans narrative voice recordings, manages noise, normalizes, and ducks background music.
 */
interface AudioAI {
    suspend fun cleanNarration(
        audioPath: String,
        noiseReduction: Boolean,
        silenceRemoval: Boolean,
        fillerRemoval: Boolean,
        breathReduction: Boolean,
        normalization: Boolean
    ): File

    fun autoDuckMusic(voiceVolume: Float, musicVolume: Float, musicActive: Boolean): Pair<Float, Float>
}

/**
 * 2. SUBTITLE AI AGENT
 * Manages word-by-word local transcript alignments and generates SRT subtitles.
 */
interface SubtitleAI {
    suspend fun generateSubtitles(audioPath: String, segments: List<TimelineSegment>): List<TimelineSegment>
    fun exportSrt(segments: List<TimelineSegment>): String
}

/**
 * 3. MOTION AI AGENT
 * Selects optimal Ken Burns camera directions, focuses, and shakes to elevate static panels.
 */
interface MotionAI {
    fun calculateOptimalMotion(segmentId: Int, durationMs: Long, segmentIndex: Int): CameraMotionConfig
}

data class CameraMotionConfig(
    val motionType: String,        // "Ken Burns", "Zoom In", "Zoom Out", "Pan Left", "Pan Right", "None"
    val motionSpeed: String,       // "Slow", "Medium", "Fast"
    val shakeIntensity: Float,     // 0.0f (no shake) to 1.0f (heavy rumble)
    val focusPoint: String,        // "Center", "Top", "Bottom", "Speech Bubble", "Character"
    val motionBlur: Boolean = true,
    val perspectiveZoom: Boolean = true
)

/**
 * 4. SCENE AI AGENT
 * Partitions narration voice files into distinct narrative scenes (sentences & pacing).
 */
interface SceneAI {
    suspend fun partitionNarration(audioPath: String, durationMs: Long): List<TimelineSegment>
}

/**
 * 5. PANEL AI AGENT
 * Redesigns selected comic/manga panels to look premium in widescreen.
 * Solves the vertical comic vs. horizontal cinema aspect ratio problem.
 */
interface PanelAI {
    fun generateWidescreenFill(imagePath: String): PanelLayoutConfig
}

data class PanelLayoutConfig(
    val mainImagePath: String,
    val leftImageBlurPath: String,
    val rightImageBlurPath: String,
    val blurOpacity: Float = 0.4f,
    val mainScale: Float = 1.0f
)

/**
 * 6. EXPORT AI AGENT
 * Handles the video/audio compilation pipeline. Uses single-scene RAM constraints.
 */
interface ExportAI {
    fun estimateExportSize(resolution: String, fps: Int, codec: String, durationMs: Long): Long
    fun estimateExportTime(resolution: String, fps: Int, codec: String, durationMs: Long): Long
    fun renderScene(segment: TimelineSegment, width: Int, height: Int, fps: Int, codec: String): Flow<RenderProgress>
}

data class RenderProgress(
    val progress: Float,
    val currentFrame: Int,
    val totalFrames: Int,
    val message: String
)

/**
 * 7. PERFORMANCE AI AGENT
 * Benchmarks offline hardware, checks system temperatures, and optimizes batterylife/RAM.
 */
interface PerformanceAI {
    fun checkThermalStatus(context: android.content.Context): String // "Normal", "Warm", "Hot", "Throttled"
    fun isBatteryOptimized(context: android.content.Context): Boolean
    fun runHardwareDiagnostic(): Flow<DiagnosticProgress>
}

data class DiagnosticProgress(
    val progress: Float,
    val currentTask: String,
    val scoreVadMs: Float,
    val scoreWhisperRatio: Float,
    val scoreGpuFps: Int
)

/**
 * 8. PROJECT AI AGENT
 * Manages templates configurations and automatically configures canvas aspects.
 */
interface ProjectAI {
    fun createDefaultTemplateConfig(templateId: String): ProjectConfigPreset
}

data class ProjectConfigPreset(
    val aspectRatio: String,         // "9:16", "16:9", "1:1"
    val resolution: String,          // "1080p", "720p", "4K"
    val defaultTransition: String,    // "Fade", "Zoom", "Slide"
    val defaultMotion: String,        // "Ken Burns", "Zoom In"
    val subtitleStyleId: Int,
    val audioProfile: String         // "Recap Dynamic", "Drama Boost"
)
