package com.example.ai

import android.content.Context
import android.os.PowerManager
import com.example.data.TimelineSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import kotlin.math.roundToInt

class AudioAIImpl : AudioAI {
    override suspend fun cleanNarration(
        audioPath: String,
        noiseReduction: Boolean,
        silenceRemoval: Boolean,
        fillerRemoval: Boolean,
        breathReduction: Boolean,
        normalization: Boolean
    ): File {
        // Simulates RNNNoise deep learning model loading and linear PCM modification
        delay(1200)
        return File(audioPath)
    }

    override fun autoDuckMusic(voiceVolume: Float, musicVolume: Float, musicActive: Boolean): Pair<Float, Float> {
        if (!musicActive) return Pair(voiceVolume, 0f)
        // Auto-ducking: dynamically reduce music to ~15% of original background level when voice over is active
        val duckedMusic = (musicVolume * 0.15f).coerceAtLeast(0.02f)
        return Pair(voiceVolume, duckedMusic)
    }
}

class SubtitleAIImpl : SubtitleAI {
    override suspend fun generateSubtitles(audioPath: String, segments: List<TimelineSegment>): List<TimelineSegment> {
        delay(1500) // Simulating Whisper Tiny alignments
        return segments.map { segment ->
            if (segment.transcriptText != null) {
                // Generate simulated word timings
                val words = segment.transcriptText.split(" ")
                val durationPerWord = (segment.endMs - segment.startMs) / words.size.coerceAtLeast(1)
                val wordTimings = words.mapIndexed { index, word ->
                    val wStart = segment.startMs + (index * durationPerWord)
                    val wEnd = wStart + durationPerWord
                    "$word|$wStart|$wEnd"
                }.joinToString(";")
                segment.copy(subText = wordTimings)
            } else {
                segment
            }
        }
    }

    override fun exportSrt(segments: List<TimelineSegment>): String {
        val srtBuilder = StringBuilder()
        val activeSegments = segments.filter { !it.isExcluded && !it.isSilence }
        
        activeSegments.forEachIndexed { index, segment ->
            val num = index + 1
            val startStr = formatSrtTime(segment.startMs)
            val endStr = formatSrtTime(segment.endMs)
            val text = segment.transcriptText ?: ""
            
            srtBuilder.append("$num\n")
            srtBuilder.append("$startStr --> $endStr\n")
            srtBuilder.append("$text\n\n")
        }
        return srtBuilder.toString()
    }

    private fun formatSrtTime(millis: Long): String {
        val ms = millis % 1000
        val sec = (millis / 1000) % 60
        val min = (millis / (1000 * 60)) % 60
        val hr = (millis / (1000 * 60 * 60)) % 24
        return String.format("%02d:%02d:%02d,%03d", hr, min, sec, ms)
    }
}

class MotionAIImpl : MotionAI {
    override fun calculateOptimalMotion(segmentId: Int, durationMs: Long, segmentIndex: Int): CameraMotionConfig {
        // AI director: alternates directions between zoom-ins, zoom-outs and slow sweeps to maintain viewer engagement
        val motions = listOf("Ken Burns", "Zoom In", "Zoom Out", "Pan Left", "Pan Right")
        val speeds = listOf("Slow", "Medium", "Slow", "Medium", "Slow")
        val focusPoints = listOf("Center", "Character", "Speech Bubble", "Top", "Bottom")

        val motionType = motions[segmentIndex % motions.size]
        val speed = speeds[segmentIndex % speeds.size]
        val focusPoint = focusPoints[segmentIndex % focusPoints.size]
        
        // High action / loud spoken words get dynamic subtle rumbles (simulates impact)
        val shake = if (segmentIndex % 4 == 0) 0.15f else 0.0f

        return CameraMotionConfig(
            motionType = motionType,
            motionSpeed = speed,
            shakeIntensity = shake,
            focusPoint = focusPoint,
            motionBlur = true,
            perspectiveZoom = true
        )
    }
}

class SceneAIImpl : SceneAI {
    override suspend fun partitionNarration(audioPath: String, durationMs: Long): List<TimelineSegment> {
        delay(2000) // Simulated voice segmentation & silence parsing (Silero VAD + Whisper)
        
        // High quality manga explanation recap scripts
        val transcripts = listOf(
            "Welcome to the Manga Recap. Today we explain the legendary battle of Chapter 250.",
            "As the protagonist unlocks his final form, the entire dimension starts to shake.",
            "Look at this gorgeous spread. The illustrator poured absolute soul into this scene.",
            "But wait... what's this? The villain releases a sudden black mist to block his sight.",
            "Is it over? No! A sudden flash of white light slices right through the shadows.",
            "With one final slash, the fate of the demon kingdom is sealed forever.",
            "Make sure to follow and subscribe for the next chapter review!"
        )

        val segments = mutableListOf<TimelineSegment>()
        var currentMs = 0L
        var order = 0
        
        val stepDuration = durationMs / transcripts.size.coerceAtLeast(1)
        
        transcripts.forEachIndexed { index, transcript ->
            val endMs = (currentMs + stepDuration).coerceAtMost(durationMs)
            
            // Introduce a natural breathing / pause segment between each epic sentence card
            val sentenceDuration = (stepDuration * 0.85f).toLong()
            val pauseDuration = stepDuration - sentenceDuration
            
            // 1. Sentence Scene Card
            segments.add(
                TimelineSegment(
                    id = order + 1,
                    projectId = 0, // Assigned later
                    startMs = currentMs,
                    endMs = currentMs + sentenceDuration,
                    playOrder = order++,
                    isSilence = false,
                    isFiller = false,
                    isExcluded = false,
                    transcriptText = transcript,
                    type = "NORMAL",
                    soundCategory = "SPEECH",
                    panelImagePath = null, // User fills this
                    cameraMotionType = when (index % 5) {
                        0 -> "Ken Burns"
                        1 -> "Zoom In"
                        2 -> "Zoom Out"
                        3 -> "Pan Left"
                        else -> "Pan Right"
                    },
                    cameraMotionSpeed = "Slow",
                    cameraShakeIntensity = if (index == 1 || index == 4) 0.3f else 0.0f,
                    cameraFocusPoint = if (index == 2) "Speech Bubble" else "Center",
                    transitionType = when (index % 4) {
                        0 -> "Fade"
                        1 -> "Zoom"
                        2 -> "Flash"
                        else -> "Slide"
                    }
                )
            )
            
            currentMs += sentenceDuration
            
            // 2. Pause Segment
            if (pauseDuration > 100 && currentMs < durationMs) {
                segments.add(
                    TimelineSegment(
                        id = order + 1,
                        projectId = 0,
                        startMs = currentMs,
                        endMs = currentMs + pauseDuration,
                        playOrder = order++,
                        isSilence = true,
                        isFiller = false,
                        isExcluded = true, // Deleted/Cut automatically!
                        transcriptText = null,
                        type = "SILENCE",
                        soundCategory = "SILENCE",
                        cameraMotionType = "None"
                    )
                )
                currentMs += pauseDuration
            }
        }
        
        return segments
    }
}

class PanelAIImpl : PanelAI {
    override fun generateWidescreenFill(imagePath: String): PanelLayoutConfig {
        // Generates widescreen overlays: Left/Right blurred instances of the vertical panel
        return PanelLayoutConfig(
            mainImagePath = imagePath,
            leftImageBlurPath = "${imagePath}_blur_left",
            rightImageBlurPath = "${imagePath}_blur_right",
            blurOpacity = 0.35f,
            mainScale = 1.0f
        )
    }
}

class ExportAIImpl : ExportAI {
    override fun estimateExportSize(resolution: String, fps: Int, codec: String, durationMs: Long): Long {
        val durationSec = durationMs / 1000.0
        val targetBitrateBps = when (resolution) {
            "4K" -> 25_000_000
            "1440p" -> 14_000_000
            "1080p" -> 8_000_000
            "720p" -> 4_000_000
            else -> 1_500_000
        }
        // Bitrate calculation scaled by codec efficiency
        val codecFactor = if (codec == "H.265") 0.65f else 1.0f
        val fpsFactor = if (fps == 60) 1.25f else 1.0f
        
        return ((targetBitrateBps * durationSec * codecFactor * fpsFactor) / 8.0).roundToInt().toLong()
    }

    override fun estimateExportTime(resolution: String, fps: Int, codec: String, durationMs: Long): Long {
        val baseSpeedRatio = when (resolution) {
            "4K" -> 0.35f   // 4K processes at 0.35x real-time
            "1440p" -> 0.75f
            "1080p" -> 2.50f  // 1080p processes at 2.5x real-time
            "720p" -> 5.00f
            else -> 10.00f
        }
        val codecModifier = if (codec == "H.265") 0.60f else 1.0f
        val actualSpeedRatio = baseSpeedRatio * codecModifier
        
        return ((durationMs / 1000.0) / actualSpeedRatio).roundToInt().toLong().coerceAtLeast(1L)
    }

    override fun renderScene(segment: TimelineSegment, width: Int, height: Int, fps: Int, codec: String): Flow<RenderProgress> = flow {
        val durationMs = segment.endMs - segment.startMs
        val totalFrames = ((durationMs / 1000.0) * fps).toInt().coerceAtLeast(1)
        
        emit(RenderProgress(0f, 0, totalFrames, "Initializing Scene ${segment.playOrder + 1} render canvas..."))
        delay(200)
        
        // Single scene chunk rendering loops
        val step = (totalFrames / 5).coerceAtLeast(1)
        for (f in 0..totalFrames step step) {
            val progress = f.toFloat() / totalFrames
            emit(
                RenderProgress(
                    progress = progress,
                    currentFrame = f,
                    totalFrames = totalFrames,
                    message = "Drawing Panel with Ken Burns [${segment.cameraMotionType}] - Frame $f/$totalFrames (${(progress * 100).toInt()}%)"
                )
            )
            delay(150)
        }
        
        emit(RenderProgress(1.0f, totalFrames, totalFrames, "Scene ${segment.playOrder + 1} completed! Written to cache."))
    }.flowOn(Dispatchers.Default)
}

class PerformanceAIImpl : PerformanceAI {
    override fun checkThermalStatus(context: Context): String {
        return try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                when (powerManager.currentThermalStatus) {
                    PowerManager.THERMAL_STATUS_NONE -> "Normal"
                    PowerManager.THERMAL_STATUS_LIGHT -> "Warm"
                    PowerManager.THERMAL_STATUS_MODERATE -> "Warm"
                    PowerManager.THERMAL_STATUS_SEVERE -> "Hot"
                    PowerManager.THERMAL_STATUS_CRITICAL -> "Throttled"
                    else -> "Normal"
                }
            } else {
                "Normal"
            }
        } catch (e: Exception) {
            "Normal"
        }
    }

    override fun isBatteryOptimized(context: Context): Boolean {
        return try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            powerManager.isPowerSaveMode
        } catch (e: Exception) {
            false
        }
    }

    override fun runHardwareDiagnostic(): Flow<DiagnosticProgress> = flow {
        emit(DiagnosticProgress(0.05f, "Initializing neural compiler...", 0f, 0f, 0))
        delay(800)
        
        emit(DiagnosticProgress(0.35f, "Benchmarking vector registers & L2/L3 latencies...", 0.65f, 0f, 0))
        delay(1000)
        
        emit(DiagnosticProgress(0.70f, "Testing MediaCodec shader thread pools...", 0.65f, 7.8f, 0))
        delay(900)
        
        emit(DiagnosticProgress(0.90f, "Computing standard mobile performance factor...", 0.65f, 7.8f, 115))
        delay(500)
        
        emit(DiagnosticProgress(1.00f, "All diagnostics complete!", 0.65f, 7.8f, 115))
    }.flowOn(Dispatchers.Default)
}

class ProjectAIImpl : ProjectAI {
    override fun createDefaultTemplateConfig(templateId: String): ProjectConfigPreset {
        return when (templateId) {
            "Manga Explanation" -> ProjectConfigPreset(
                aspectRatio = "16:9",
                resolution = "1080p",
                defaultTransition = "Fade",
                defaultMotion = "Ken Burns",
                subtitleStyleId = 1, // High contrast yellow Bangers font
                audioProfile = "Recap Dynamic"
            )
            "Manhwa Recap" -> ProjectConfigPreset(
                aspectRatio = "16:9",
                resolution = "1080p",
                defaultTransition = "Zoom",
                defaultMotion = "Zoom In",
                subtitleStyleId = 2, // Modern Neon Slate font
                audioProfile = "Drama Boost"
            )
            "Comic Recap" -> ProjectConfigPreset(
                aspectRatio = "16:9",
                resolution = "1080p",
                defaultTransition = "Slide",
                defaultMotion = "Pan Left",
                subtitleStyleId = 3,
                audioProfile = "Dialogue Crisp"
            )
            "YouTube Shorts" -> ProjectConfigPreset(
                aspectRatio = "9:16",
                resolution = "1080p",
                defaultTransition = "Zoom",
                defaultMotion = "Zoom In",
                subtitleStyleId = 4, // Bold TikTok dynamic highlight
                audioProfile = "Dialogue Crisp"
            )
            "TikTok" -> ProjectConfigPreset(
                aspectRatio = "9:16",
                resolution = "1080p",
                defaultTransition = "Flash",
                defaultMotion = "Zoom Out",
                subtitleStyleId = 4,
                audioProfile = "Dialogue Crisp"
            )
            "Instagram Reels" -> ProjectConfigPreset(
                aspectRatio = "9:16",
                resolution = "1080p",
                defaultTransition = "Blur",
                defaultMotion = "Pan Right",
                subtitleStyleId = 5,
                audioProfile = "Recap Dynamic"
            )
            else -> ProjectConfigPreset(
                aspectRatio = "16:9",
                resolution = "1080p",
                defaultTransition = "Fade",
                defaultMotion = "Ken Burns",
                subtitleStyleId = 1,
                audioProfile = "Recap Dynamic"
            )
        }
    }
}
