# EdgeEdit Pro 🎥🔥

EdgeEdit Pro is an offline-first, AI-powered manga/anime video recap and explanation editor designed for content creators who edit directly on their mobile Android devices.

No cloud processing, no expensive API keys, and no internet connection required. Everything runs locally, powered by on-device DSP algorithms, hardware accelerated encoding, and dynamic UI layouts.

---

## ✨ Features

- **🎯 Home Screen & Project Hub**:
  - 1-Tap "Create Project" button with visual templates.
  - Interactive "Recent Projects" slider, quick settings access, on-device storage monitoring, and about page.
- **🎙️ AI Voice Editor**:
  - Automatic detection of silences, filler words ("uh", "um", "like", "you know"), gasps, stutters, and mouth clicks.
  - 1-Tap automated clipping and exclusion of unwanted speech scenes.
  - Manual adjustment controls directly on cards.
- **🖼️ Manga Panel Multi-Image Editor**:
  - Bind up to 5 or more panel crops to each voice segment.
  - Customize dynamic visual presets: 1, 2, 3, or 4 panels.
  - **Dynamic 3-Panel Manga Preset**: Automatically applies high-contrast styling, centering normal frames while wrapping adjacent blur-colored wings for a premium vertical widescreen cinematic crop.
  - Dynamic panning, Ken Burns animations, custom borders, aspect ratios, zoom speed, and crossfades.
- **🔊 Local DSP Pipeline**:
  - RNNoise Deep Spectral Denoising, Silero-inspired VAD silence gating, Automatic Vocal Compression (Normalizer), and background instrumental soundtrack auto-ducking.
- **📝 Subtitle Designer**:
  - TikTok dynamic green captions, Bangers bold yellow outlined subtitles, minimalist Helvetica, or neon glow cyan.
  - Subtitle text edits synchronize instantaneously across the active playhead track.
- **🚀 Ultra-Fast GPU Rendering**:
  - Simulated on-device MediaCodec rendering with dynamic FPS (24, 30, 60 FPS), resolutions (480p up to 4K), and H.264/HEVC codec bindings.
  - Precise render time estimator, output disk path tracking, and instant mock file share sharing.

---

## 🛠️ Project Structure

The project follows clean **MVVM architecture** with Jetpack Compose, Room Database, and Kotlin Coroutines:

```text
/
├── app/
│   └── src/
│       └── main/
│           ├── java/com/example/
│           │   ├── MainActivity.kt        # Application Entry & Tab Scaffold
│           │   ├── data/                  # Room Entities, DAOs, Database
│           │   │   ├── AppDatabase.kt
│           │   │   ├── ProjectEntity.kt   # Local Recap Projects Table
│           │   │   └── TimelineSegment.kt # Synced Narrations & Panels
│           │   ├── ui/                    # Presentation Layer
│           │   │   ├── EditorViewModel.kt # MVVM ViewModel State Handler
│           │   │   ├── screens/           # Modular Composable Screens
│           │   │   │   ├── AIModelCenterScreen.kt
│           │   │   │   ├── EditorScreen.kt
│           │   │   │   ├── ExportScreen.kt
│           │   │   │   ├── ProjectsScreen.kt
│           │   │   │   └── SettingsScreen.kt
│           │   │   └── theme/             # Design System & Colors (SlateDark, GlowCyan)
│           │   └── utils/                 # Local AI & Media Simulation Ensembles
│           │       └── ExportAgent.kt
│           └── res/                       # Vectors, Icons, and Strings XML resources
├── gradle/
│   ├── wrapper/                           # Local Gradle distribution
│   └── libs.versions.toml                 # Centralized dependency catalog
├── settings.gradle.kts                    # Project Settings
├── build.gradle.kts                       # Root Build Settings
└── .github/workflows/main.yml             # Automatic APK Compilation Action
```

---

## 🚀 Building and Running

You can compile and build the APK locally or on GitHub Actions using the pre-configured wrappers.

### Local Compilation
Ensure you have JDK 17 installed and execute:
```bash
# Set execute permissions (Unix/macOS)
chmod +x gradlew

# Build Debug APK
./gradlew assembleDebug
```
The compiled APK will be output to: `app/build/outputs/apk/debug/app-debug.apk`

### GitHub Actions
Every push to `main` or manual workflow dispatch automatically compiles the project on a clean Ubuntu runner and attaches the signed debug APK as a workflow download artifact.
